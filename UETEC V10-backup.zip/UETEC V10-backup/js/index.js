/*DICA 01: INICIO CLASSE DO MENU RESPONSIVO E PROPRIEDADES*/

class NavegacaoMobile { /*Cria um molde de objeto */
    constructor(menuResponsivo, menuTopo, menuLinks) { /* Recebe seletores CSS como parâmetros. */

        this.menuResponsivo = document.querySelector(menuResponsivo); /*botão do menu hamburguer*/
        this.menuTopo = document.querySelector(menuTopo); /*opções do menu  ""PEGA""*/
        this.menuLinks = document.querySelectorAll(menuLinks); /*links das opções Pega todos os links dentro do menu.*/
        this.classeAtivo = "ativo"; /*classe ativo controla se o menu está aberto ou fechado*/
        this.handleClick = this.handleClick.bind(this); /*"this" se torna a classe "NavegacaoMobile" / garante que dentro de handleClick(), o this sempre será o objeto da classe*/
       
    }
    handleClick() { /*função que abre/fecha o menu */
        this.menuTopo.classList.toggle(this.classeAtivo); /*Adiciona a classe "ativo" se ela não existir, ou remove se existir */
        this.menuResponsivo.classList.toggle(this.classeAtivo); 
    }

    addClickEvent() { /*evento de clique */
        this.menuResponsivo.addEventListener("click", this.handleClick); /*executa handleClick() */
    }

    init() { /* Inicializa a classe */
        if (this.menuResponsivo) {
            this.addClickEvent();
        }
        return this; 
    }
}

const navegacaoMobile = new NavegacaoMobile( /* cria instância da classe */
    ".menu-responsivo", /* Cria o objeto com os seletores, Liga o menu na página, Inicializa o comportamento de abrir/fechar */
    ".menu-topo", 
    ".menu-topo li", 
);

navegacaoMobile.init(); 

/*DICA 01: FIM CLASSE DO MENU RESPONSIVO E PROPRIEDADES*/


/* INÍCIO DO CÓDIGO DE ALTERNÂNCIA DE IMAGENS */
document.addEventListener('DOMContentLoaded', function() { /* Espera carregar o DOM / Garante que HTML já exista antes do JS*/
    
    // 1. Obtém o elemento IMG pelo ID 'carrossel'
    const uniformeAlternador = document.getElementById('carrossel'); /* Pega a imagem principal */
    
    // Se não encontrar o elemento, para a execução do carrossel
    if (!uniformeAlternador) {
        console.error("Elemento com ID 'carrossel' não encontrado.");
        return; 
    }
    
    // 2. Define os caminhos das imagens (verificados como corretos)
    const imagensUniformes = [
        'imagens/uniformeAzul.webp', /* imagens do carrossel */
        'imagens/uniformeBranco.webp', 
        'imagens/uniformePreto.webp' 
    ];
    
    let currentIndex = 0; // Começa com o uniformeAzul (que já está no HTML)

    function alternarUniforme() { /* função da troca de imagens */
        // Calcula o próximo índice, voltando a zero após o último elemento
        currentIndex = (currentIndex + 1) % imagensUniformes.length; /* volta para o começo depois da última imagem. */
        // Altera a fonte da imagem
        uniformeAlternador.src = imagensUniformes[currentIndex];
    }

    // 3. Inicia o carrossel, alternando a cada 3 segundos (3000ms)
    setInterval(alternarUniforme, 3000); 
    
});
/* FIM DO CÓDIGO DE ALTERNÂNCIA DE IMAGENS */