// ============================================
// QUANDO A PÁGINA CARREGAR
// ============================================
document.addEventListener('DOMContentLoaded', function() { /* garante que o JS só execute depois do HTML tá 100%*/

    const linksMenu = document.querySelectorAll('.menu-lateral a'); /* Seleciona links do menu *TODOS* */
    const secoesConteudo = document.querySelectorAll('.secao-conteudo'); /* seleciona as seções de conteúdo *TODAS*  */

    // Esconde todas as seções no início
    secoesConteudo.forEach(secao => { // Percorre cada seção encontrada
        secao.classList.add('escondido'); // Adiciona classe "escondido"
    });

    // Mostra a primeira seção por padrão
    const primeiraSecao = document.getElementById('status-produtos'); // procura elemento id="status-produtos" e guarda em primeiraSecao.
    if (primeiraSecao) {
        primeiraSecao.classList.remove('escondido'); // Remove classe "escondido" (torna visível)
        //  CARREGAR DADOS DA PRIMEIRA SEÇÃO
        carregarDadosSecao('status-produtos'); // Chama função para carregar dados dessa seção do servidor
    }

    // Adiciona o evento de clique a todos os links do menu

    linksMenu.forEach(link => { /* percorre cada link do menu */
        link.addEventListener('click', function(event) { // adiciona um ouvinte de evento
            // Verifica se o link clicado tem a classe 'secao'
            if (this.classList.contains('secao')) { // verifica se link tem classe secao
                event.preventDefault(); // Impede a ação padrão apenas para links de seção
                
                // obs: "this" = o elemento que foi clicado

                // Esconde todas as seções
                secoesConteudo.forEach(secao => { // percorre todas as seções
                    secao.classList.add('escondido'); // adiciona classe "escondido"
                });

                // Mostra a seção correspondente ao link clicado
                const targetId = this.getAttribute('data-target'); // lê o atributo data-target do link
                const secaoAlvo = document.getElementById(targetId); // busca elemento da página id
                if (secaoAlvo) { // se existir secaoAlvo
                    secaoAlvo.classList.remove('escondido'); // torna a seção visível.
                    //  CARREGAR DADOS AO TROCAR DE SEÇÃO
                    carregarDadosSecao(targetId); // pede busca de dados da seção aberta
                }
            }
        });
    });

    //  CONFIGURAR FORMULÁRIOS
    configurarFormularios(); // chama função de configurar todos os forms da página
});

// ============================================
//  CARREGAR DADOS DE CADA SEÇÃO
// ============================================
function carregarDadosSecao(secao) { /* recebe um ID da seção aberta e usa um switch para decidir qual função chamar / define uma função chamada carregarDadosSecao que recebe uma string secao*/
    console.log('Carregando dados de:', secao);
    
    switch(secao) { // analisa a variável secao/Funciona como "desvio" dependendo do valor secao, executa função diferente
        case 'dashboard':
            carregarDashboard();
            break;
        case 'status-produtos':
            carregarProdutos();
            break;
        case 'relatorio-vendas':
            carregarRelatorioVendas();
            break;
        case 'pedidos':
            carregarPedidos();
            break;
    }
}

// ============================================
//  DASHBOARD
// "async" permite usar "await" dentro da função
async function carregarDashboard() {  //define função assíncrona
    try { // tenta executar código, deu ruim -> vai pro catch
        const response = await fetch('api_admin.php?acao=dashboard'); /* Busca informações numéricas fazendo requisição HTTP*/
        const dados = await response.json(); // lê corpo resposta como JSON e transforma em objeto JavaScript, guardado em dados.
        
        // obs: await -> "Espera" a promessa ser resolvida antes de continuar
        // fetch(): Faz requisição HTTP (busca dados do servidor)

        console.log('Dashboard:', dados);
        
        // Busca elemento onde vai inserir os dados
        const dashboard = document.querySelector('#dashboard .secao-gerenciamento'); // procura dentro do elemento com id="dashboard" elemento com classe .secao-gerenciamento
        dashboard.innerHTML = ` 
            <h3>Resumo da Atividade</h3>
            <p>Pedidos hoje: ${dados.pedidos_hoje} novos pedidos</p>
            <p>Faturamento do dia: R$ ${dados.faturamento_hoje}</p>
            <p>Total de produtos: ${dados.total_produtos}</p>
            <p>Produtos com estoque baixo: ${dados.estoque_baixo}</p>
        `; // substitui o conteúdo HTML dentro daquele elemento por um template (texto HTML) usando **template literals** 


    } catch (erro) { // caso internet ou servidor cair, mesnsagem de erro
        console.error('Erro ao carregar dashboard:', erro);
        alert(' Erro ao carregar dashboard');
    }
}

// ============================================
//  LISTAR PRODUTOS
// ============================================
async function carregarProdutos() { // declara função como assíncrona, buscar e exibir produtos
    try { // bloco para tratar possíveis erros
        const response = await fetch('api_admin.php?acao=listar_produtos'); // envia pedido ao servidor para obter lista de produtos
        const produtos = await response.json(); // converte resposta em JSON (um array de produtos)
        
        
        console.log('Produtos carregados:', produtos);
        
        const tbody = document.querySelector('#status-produtos tbody'); // seleciona <tbody> da tabela onde serão inseridas linhas
        tbody.innerHTML = ''; // limpa conteúdo anterior dentro do <tbody>
        
        if (produtos.length === 0) { // verifica se array de produtos está vazio
            // Se não tem produtos, mostra mensagem
            // colspan="3" faz célula ocupar 3 colunas
            tbody.innerHTML = '<tr><td colspan="3" style="text-align: center;">Nenhum produto cadastrado</td></tr>'; // mostra linha indica que não há produtos
            return; // sai da função
        }
        
        produtos.forEach(produto => { // percorre cada produto do array
            // Operador ternário: condição ? valorSeVerdadeiro : valorSeFalso
            const status = produto.estoque > 0 // verifica se existe estoque
                ? `${produto.estoque} Em Estoque` // se tiver, monta string com quantidade
                : 'Fora de Estoque'; // se não tiver, define como "Fora de Estoque"
            
            const tr = document.createElement('tr'); // cria um elemento <tr> (nova linha da tabela)
            
            // Define conteúdo HTML da linha
            tr.innerHTML = `
                <td>${produto.nome}</td>
                <td>${status}</td>
                <td>${formatarData(new Date())}</td>
            `; // define conteúdo HTML das células dessa linha
            tbody.appendChild(tr); // adiciona linha criada ao final do <tbody>
        });
    } catch (erro) { // captura erro dentro do try
        console.error('Erro ao carregar produtos:', erro);
        alert(' Erro ao carregar produtos. Verifique se o arquivo api_admin.php existe.');
    }
}

// ============================================
//  LISTAR PEDIDOS
// ============================================
async function carregarPedidos() { // função assíncrona para buscar pedidos no servidor
    try { // inicia bloco para capturar erros
        const response = await fetch('api_admin.php?acao=listar_pedidos'); // envia requisição pedindo a lista de pedidos
        const pedidos = await response.json(); // converte a resposta em JSON (array de pedidos)
        
        console.log('Pedidos carregados:', pedidos);
        
        const tbody = document.querySelector('#pedidos tbody'); //  seleciona o corpo da tabela de pedidos
        tbody.innerHTML = ''; // limpa dados anteriores
        
        if (pedidos.length === 0) { // verifica se não há pedidos cadastrados
            tbody.innerHTML = '<tr><td colspan="4" style="text-align: center;">Nenhum pedido encontrado</td></tr>';
            return; // para aqui
        }
        
        pedidos.forEach(pedido => { // percorre cada pedido recebido
            const tr = document.createElement('tr'); // cria uma nova linha da tabela
            
            // Preenche células com dados do pedido
            tr.innerHTML = `
                <td>#${pedido.id_pedido}</td>
                <td>${pedido.nome} ${pedido.sobrenome}</td>
                <td>${formatarData(new Date(pedido.data_pedido))}</td>
                <td>${traduzirStatus(pedido.status)}</td>
            `; // insere o conteúdo HTML da linha
            tbody.appendChild(tr); // adiciona a linha no <tbody>

            // obs: new Date(pedido.data_pedido): Converte string em objeto Date
        });
    } catch (erro) { // caso de ruim
        console.error('Erro ao carregar pedidos:', erro);
        alert(' Erro ao carregar pedidos');
    }
}

// ============================================
// RELATÓRIO DE VENDAS
// ============================================
async function carregarRelatorioVendas() { // função assíncrona para buscar informações do relatório de vendas
    try { // bloco para tratar erros
        const response = await fetch('api_admin.php?acao=relatorio_vendas'); // Requisição para buscar estatísticas de vendas
        const dados = await response.json(); // converte resposta para JSON
        
        console.log('Relatório carregado:', dados);
        
         // Seleciona área onde vai inserir relatório
        const relatorio = document.querySelector('#relatorio-vendas .secao-gerenciamento'); 
        
        // Insere HTML com dados do relatório
        relatorio.innerHTML = `
            <h3>Vendas Totais</h3>
            <p>Valor total de vendas nos últimos 30 dias: R$ ${dados.total_vendas}</p>
            <p>Item mais vendido: ${dados.mais_vendido}</p>
            <p>Item menos vendido: ${dados.menos_vendido}</p>
        `;
    } catch (erro) { // trata erros
        console.error('Erro ao carregar relatório:', erro);
        alert(' Erro ao carregar relatório');
    }
}

// ============================================
//  FORMULÁRIOS
// ============================================
function configurarFormularios() { // configura todos os formulários
    configurarFormAdicionar(); // configura form adicionar produto
    configurarFormRemover(); // configura form remover produto
    configurarFormEstoque(); // configura form atualizar estoque
    configurarFormNome();
    configurarFormDescricao();
    configurarFormPreco();
    configurarFormImagem();
}

// Formulário: ADICIONAR PRODUTO
function configurarFormAdicionar() {

     // Seleciona PRIMEIRO formulário dentro de #comfigurar-produtos
    const form = document.querySelector('#comfigurar-produtos form:first-of-type');

     // Seleciona input de imagem
    const inputImagem = document.getElementById('nova-imagem-produto');
    
    if (!form) { // Se não encontrou formulário
        console.warn('Formulário de adicionar não encontrado');
        return;
    }
    
    form.addEventListener('submit', async function(e) { //adiciona ouvinte d evento "submit" (quando enviado formulário)
        e.preventDefault(); // impede comportamento (recarregar página)
        
        const nome = document.getElementById('novo-produto').value.trim(); // pega valor campo nome e remove espaço pontas
        // Obtendo valores de todos os campos

        const descricao = document.getElementById('descricao-novo-produto').value.trim(); // pega valor campo descricao
        const preco = document.getElementById('preco-novo-produto').value; // pega valor campo preço
        const estoque = document.getElementById('estoque-novo-produto').value; // pega valor campo estoque
        const categoria = document.getElementById('categoria-novo-produto').value; // pega valor categoria
        
        const imagem = inputImagem.files[0]; // pega 1º arquivo selecionado no input de img
        
        // verifica se campos obrigatórios foram preenchidos *VALIDAÇÃO*
        if (!nome || !preco || !estoque) {
            alert('Preencha os campos obrigatórios (Nome, Preço e Estoque)!');
            return; // para execução aqui
        }
        
        const formData = new FormData(); // cria objeto Formdata para enviar dados e arquivos
        formData.append('nome', nome);
        // Adicionando novos campos ao FormData
        formData.append('descricao', descricao);
        formData.append('preco', preco);
        formData.append('estoque', estoque);
        formData.append('id_categoria', categoria);
        
        if (imagem) { // caso usuario selecione img
             formData.append('imagem_produto', imagem); // adiciona img ao FormData
        }
        
        console.log('Adicionando produto:', nome, preco, imagem ? imagem.name : 'Sem imagem');
        
        try {
            // enviar requisição post ao servidor
            const response = await fetch('api_admin.php?acao=adicionar_produto', {
                method: 'POST', // metodo http
                body: formData // dados sendo enviados
            });
            
            const resultado = await response.json(); // converte *resposta -> objeto*
            console.log('Resultado:', resultado); // resposta do servidor
            
            if (resultado.sucesso) { // se deu bom
                alert(' Produto adicionado com sucesso!');
                form.reset(); // limpa os campos 
                carregarProdutos(); // recarrega lista de produtos
            } else {
                // se retornar com erro
                alert('❌ ' + resultado.erro);
            }
        } catch (erro) {
            // trata erros de rede, servidor e +
            console.error('Erro ao adicionar:', erro);
            alert(' Erro ao adicionar produto. Verifique o console (F12).');
        }
    });
}

// Formulário: REMOVER PRODUTO
function configurarFormRemover() {
    // Seleciona último formulário dentro de #comfigurar-produtos
    const form = document.querySelector('#form-remover');
    
    if (!form) { // validacao de segurança
        console.warn('Formulário de remover não encontrado');
        return;
    }
    
    form.addEventListener('submit', async function(e) { // ouvinte de submit
        e.preventDefault(); // impede recarregar página

        const nomeProduto = document.getElementById('remover-produto').value.trim(); // pega nome produto digitado
        
        console.log('Formulário enviado!');
console.log('Nome digitado:', nomeProduto);
        
        
        if (!nomeProduto) { // verifica se campo foi preenchido *VALIDACAO*
            alert(' Digite o nome do produto!');
            return;
        }
        
        console.log('Procurando produto:', nomeProduto);
        
        try {
            // Buscar o produto pelo nome

            // busca lista completa de produtos
            const response = await fetch('api_admin.php?acao=listar_produtos');
            const produtos = await response.json();

            // Procura produto com nome correspondente (case-insensitive)
            const produto = produtos.find(p => 
                p.nome.toLowerCase() === nomeProduto.toLowerCase()
            );
            
            if (!produto) { // caso não encontre produto
                alert(' Produto "' + nomeProduto + '" não encontrado!\n\nProdutos disponíveis:\n' + produtos.map(p => p.nome).join('\n')); // alerta de lista de produtos disponiveis
                return; 
            }
            
            // Confirmar antes de remover

            // mostra janela confirmacao
            if (!confirm(`Tem certeza que deseja remover "${produto.nome}"?`)) {
                return; // se usuario cancelar, para ai
            }
            
            console.log('Removendo produto ID:', produto.id_produto);
            
            // Remover o produto

            // envia requisicao post pra remover
            const responseRemover = await fetch('api_admin.php?acao=remover_produto', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json' // informa envio JSON
                },
                body: JSON.stringify({ id: produto.id_produto }) // converte objeto para JSON
            });
            
            const resultado = await responseRemover.json(); // converte resposta
            console.log('Resultado:', resultado);
            
            if (resultado.sucesso) { // se remover com sucesso
                alert(' Produto removido com sucesso!');
                form.reset(); // limpa campo
                carregarProdutos(); // recarrega lista
            } else { // se deu errado
                alert('❌ ' + resultado.erro);
            }
        } catch (erro) {

            // trata erros
            console.error('Erro ao remover:', erro);
            alert(' Erro ao remover produto. Verifique o console (F12).');
        }
    });
}

// Formulário: ATUALIZAR ESTOQUE
function configurarFormEstoque() {

    // seleciona form de estoque
    const form = document.querySelector('#edicao-estoque form');
    
    if (!form) { // validacao
        console.warn('Formulário de estoque não encontrado');
        return;
    }
    
    form.addEventListener('submit', async function(e) { // ouvinte de submit
        e.preventDefault(); // impede recarregar
        
        const nomeProduto = document.getElementById('produto-estoque').value.trim(); // pega nome produto
        const quantidade = document.getElementById('quantidade-estoque').value; // pega quantidade estoque
        
        if (!nomeProduto || !quantidade) { // ambos campos deveme estar preeenchidos *VALIDACAO*
            alert(' Preencha todos os campos!');
            return;
        }
        
        console.log('Atualizando estoque:', nomeProduto, quantidade);
        
        try {
            // Buscar produto pelo nome
            const response = await fetch('api_admin.php?acao=listar_produtos');
            const produtos = await response.json();

             // Procura produto (case-insensitive)
            const produto = produtos.find(p => 
                p.nome.toLowerCase() === nomeProduto.toLowerCase()
            );
            
            if (!produto) { // se não encontrar 
                alert(' Produto "' + nomeProduto + '" não encontrado!\n\nProdutos disponíveis:\n' + produtos.map(p => p.nome).join('\n'));
                return;
            }
            
            console.log('Produto encontrado ID:', produto.id_produto);
            
            // Atualizar estoque
            const responseAtualizar = await fetch('api_admin.php?acao=atualizar_estoque', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    id: produto.id_produto, // ID produto
                    quantidade: quantidade // nova quantidade
                })
            });
            
            // converte respostas para JSON
            const resultado = await responseAtualizar.json();
            console.log('Resultado:', resultado);
            
            if (resultado.sucesso) { // se atualizar com sucesso
                alert(' Estoque atualizado com sucesso!');
                form.reset(); // limpa campos
                carregarProdutos(); // recarrega lista
            } else {
                alert('❌ ' + resultado.erro); // se der erro
            }
        } catch (erro) {
            console.error('Erro ao atualizar:', erro);
            alert('Erro ao atualizar estoque. Verifique o console (F12).');
        }
    });
}

function configurarFormDescricao() {

     const form = document.querySelector('#form-descricao');

      console.log('Formulário de descrição encontrado:', form); // ← ADICIONE ESTA LINHA
    
    if (!form) { // validacao
        console.warn('Formulário de descricao não encontrado');
        return;
    }
    
    form.addEventListener('submit', async function(e) { // ouvinte de submit
        e.preventDefault(); // impede recarregar
        
        const nomeProduto = document.getElementById('produto-descricao').value.trim();
        const novaDescricao = document.getElementById('nova-descricao').value.trim();
        
        if (!nomeProduto || !novaDescricao) { // ambos campos deveme estar preeenchidos *VALIDACAO*
            alert('Preencha o nome do produto e a nova descrição!');
            return;
        }
        
        console.log('Atualizando descricao:', nomeProduto, novaDescricao);
        
        try {
            // Buscar produto pelo nome
            const response = await fetch('api_admin.php?acao=listar_produtos');
            const produtos = await response.json();

             // Procura produto (case-insensitive)
            const produto = produtos.find(p => 
                p.nome.toLowerCase() === nomeProduto.toLowerCase()
            );
            
            if (!produto) { // se não encontrar 
                alert(' Produto "' + nomeProduto + '" não encontrado!\n\nProdutos disponíveis:\n' + produtos.map(p => p.nome).join('\n'));
                return;
            }
            
            console.log('Produto encontrado ID:', produto.id_produto);
            
            // Atualizar estoque
            const responseAtualizar = await fetch('api_admin.php?acao=atualizar_descricao', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    id: produto.id_produto,
                    descricao: novaDescricao
                })
            });
            
            // converte respostas para JSON
            const resultado = await responseAtualizar.json();
            console.log('Resultado:', resultado);
            
            if (resultado.sucesso) { // se atualizar com sucesso
                alert(' Descricao atualizada com sucesso!');
                form.reset(); // limpa campos
                carregarProdutos(); // recarrega lista
            } else {
                alert('❌ ' + resultado.erro); // se der erro
            }
        } catch (erro) {
            console.error('Erro ao atualizar:', erro);
            alert('Erro ao atualizar descricao. Verifique o console (F12).');
        }
    });
}

function configurarFormPreco() {
    const form = document.querySelector('#form-preco');
    
    if (!form) {
        console.warn('Formulário de preço não encontrado');
        return;
    }
    
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const nomeProduto = document.getElementById('produto-preco').value.trim();
        const novoPreco = document.getElementById('novo-preco').value;
        
        if (!nomeProduto || !novoPreco) {
            alert('⚠️ Preencha o nome do produto e o novo preço!');
            return;
        }
        
        console.log('Atualizando preço:', nomeProduto, novoPreco);
        
        try {
            const response = await fetch('api_admin.php?acao=listar_produtos');
            const produtos = await response.json();
            
            const produto = produtos.find(p => 
                p.nome.toLowerCase() === nomeProduto.toLowerCase()
            );
            
            if (!produto) {
                alert('❌ Produto "' + nomeProduto + '" não encontrado!\n\nProdutos disponíveis:\n' + 
                      produtos.map(p => p.nome).join('\n'));
                return;
            }
            
            console.log('Produto encontrado ID:', produto.id_produto);
            
            const responseAtualizar = await fetch('api_admin.php?acao=atualizar_preco', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    id: produto.id_produto,
                    preco: novoPreco
                })
            });
            
            const resultado = await responseAtualizar.json();
            console.log('Resultado:', resultado);
            
            if (resultado.sucesso) {
                alert('✅ Preço atualizado com sucesso!');
                form.reset();
                carregarProdutos();
            } else {
                alert('❌ ' + resultado.erro);
            }
        } catch (erro) {
            console.error('Erro ao atualizar:', erro);
            alert('❌ Erro ao atualizar preço. Verifique o console (F12).');
        }
    });
}

function configurarFormImagem() {
    const form = document.querySelector('#form-imagem');
    
    if (!form) {
        console.warn('Formulário de imagem não encontrado');
        return;
    }
    
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const nomeProduto = document.getElementById('produto-imagem').value.trim();
        const inputImagem = document.getElementById('nova-imagem');
        const imagem = inputImagem.files[0];
        
        if (!nomeProduto || !imagem) {
            alert('⚠️ Preencha o nome do produto e selecione uma imagem!');
            return;
        }
        
        console.log('Atualizando imagem:', nomeProduto, imagem.name);
        
        try {
            // Buscar produto pelo nome
            const response = await fetch('api_admin.php?acao=listar_produtos');
            const produtos = await response.json();
            
            const produto = produtos.find(p => 
                p.nome.toLowerCase() === nomeProduto.toLowerCase()
            );
            
            if (!produto) {
                alert('❌ Produto "' + nomeProduto + '" não encontrado!\n\nProdutos disponíveis:\n' + 
                      produtos.map(p => p.nome).join('\n'));
                return;
            }
            
            console.log('Produto encontrado ID:', produto.id_produto);
            
            // Criar FormData para enviar arquivo
            const formData = new FormData();
            formData.append('id', produto.id_produto);
            formData.append('imagem', imagem);
            
            const responseAtualizar = await fetch('api_admin.php?acao=atualizar_imagem', {
                method: 'POST',
                body: formData // ← NÃO usa JSON.stringify com FormData!
            });
            
            const resultado = await responseAtualizar.json();
            console.log('Resultado:', resultado);
            
            if (resultado.sucesso) {
                alert('✅ Imagem atualizada com sucesso!');
                form.reset();
                carregarProdutos();
            } else {
                alert('❌ ' + resultado.erro);
            }
        } catch (erro) {
            console.error('Erro ao atualizar:', erro);
            alert('❌ Erro ao atualizar imagem. Verifique o console (F12).');
        }
    });
}

function configurarFormNome() {
    // Seleciona form de nome
    const form = document.querySelector('#edicao-nome form');
    
    if (!form) {
        console.warn('Formulário de nome não encontrado');
        return;
    }
    
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const nomeProdutoAtual = document.getElementById('produto-nome').value.trim();
        const novoNome = document.getElementById('novo-nome').value.trim(); // ✅ CORRIGIDO: era 'nome', agora é 'novo-nome'
        
        // Validação
        if (!nomeProdutoAtual || !novoNome) {
            alert('⚠️ Preencha todos os campos!');
            return;
        }
        
        console.log('Atualizando nome:', nomeProdutoAtual, '->', novoNome);
        
        try {
            // Buscar produto pelo nome atual
            const response = await fetch('api_admin.php?acao=listar_produtos');
            const produtos = await response.json();
            
            // Procura produto (case-insensitive)
            const produto = produtos.find(p => 
                p.nome.toLowerCase() === nomeProdutoAtual.toLowerCase()
            );
            
            if (!produto) {
                alert('❌ Produto "' + nomeProdutoAtual + '" não encontrado!\n\nProdutos disponíveis:\n' + 
                      produtos.map(p => p.nome).join('\n'));
                return;
            }
            
            console.log('Produto encontrado ID:', produto.id_produto);
            
            // Atualizar nome
            const responseAtualizar = await fetch('api_admin.php?acao=atualizar_nome', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    id: produto.id_produto,
                    nome: novoNome
                })
            });
            
            const resultado = await responseAtualizar.json();
            console.log('Resultado:', resultado);
            
            if (resultado.sucesso) {
                alert('✅ Nome atualizado com sucesso!');
                form.reset();
                carregarProdutos(); // Recarrega lista
            } else {
                alert('❌ ' + resultado.erro);
            }
        } catch (erro) {
            console.error('Erro ao atualizar:', erro);
            alert('❌ Erro ao mudar o nome. Verifique o console (F12).');
        }
    });
}

// ============================================
// FUNÇÕES AUXILIARES
// ============================================

// Recebe objeto Date e retorna string no formato "DD/MM/AAAA"
function formatarData(data) {

    // Pega dia do mês (1-31)
    // String() converte número em texto
    // padStart(2, '0') garante 2 dígitos (ex: 5 → 05)
    const dia = String(data.getDate()).padStart(2, '0');

    // Pega mês (0-11, por isso +1)
    // Janeiro=0, Fevereiro=1... Dezembro=11
    const mes = String(data.getMonth() + 1).padStart(2, '0');

    // Pega ano completo (2025)
    const ano = data.getFullYear();

    // Retorna string formatada
    return `${dia}/${mes}/${ano}`;
}

// Recebe status em inglês/minúsculo e retorna traduzido
function traduzirStatus(status) {

    // Objeto com traduções (mapa chave-valor)
    const traducoes = {
        'pendente': 'Pendente',
        'pago': 'Pago',
        'enviado': 'Enviado',
        'cancelado': 'Cancelado'
    };

    // Tenta buscar tradução
    // Se não existir (undefined), retorna status original
    // Operador || retorna primeiro valor "verdadeiro"
    return traducoes[status] || status;
}