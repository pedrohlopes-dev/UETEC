// Obtenha referências aos elementos do formulário e aos botões/links

// busca forms na paǵina pelo ID
const formularioLogin = document.getElementById('formularioLogin');
const formularioCadastro = document.getElementById('formularioCadastro');

//Busca os botões/links de navegação
const linkCriarConta = document.getElementById('linkCriarConta');
const botaoVoltar = document.getElementById('botaoVoltar');
const botaoAvancarLogin = document.getElementById('botaoAvancarLogin'); // Esta linha é crucial

// Adicione um ouvinte de evento para o link "Criar nova conta"
linkCriarConta.addEventListener('click', (evento) => {
  evento.preventDefault(); // impede ir para outra pagina
  formularioLogin.style.display = 'none'; // esconde login
  formularioCadastro.style.display = 'block'; // mostra cadastro
});

// Adicione um ouvinte de evento para o botão "Voltar"
botaoVoltar.addEventListener('click', (evento) => { // quando clicar no botao voltar
  evento.preventDefault(); // impede envio de form
  formularioCadastro.style.display = 'none'; // esconde cadastro
  formularioLogin.style.display = 'block'; // mostra login
});

// Adicione um ouvinte de evento para o botão "Avançar" do formulário de LOGIN
botaoAvancarLogin.addEventListener('click', (evento) => {
  // Descomente esta linha se o botão estiver dentro de um <form> e você não quiser que a página recarregue
  // evento.preventDefault(); 

  // Mostra o formulário de cadastro e esconde o de login
  formularioLogin.style.display = 'none'; // esconde login
  formularioCadastro.style.display = 'block'; // mostra cadastro
});

// colocar a quantidade de numeros de telefone e os parênteses

const telefoneInput = document.getElementById('telefone');

// Executa toda vez que usuário digita no campo telefone
telefoneInput.addEventListener('input', function (e) {
  let valor = e.target.value; // Pega texto atual do campo

  // Remove tudo que não for número
  valor = valor.replace(/\D/g, '');

  // Adiciona parênteses, espaço traço automaticamente
  if (valor.length > 0) {
    valor = '(' + valor; // "11" → "(11"
  }

  // Adiciona ') ' após os 2 primeiros dígitos (DDD)
  if (valor.length > 3) {
    valor = valor.slice(0,3) + ') ' + valor.slice(3); // "(11" → "(11) 9"
  }

   // Adiciona '-' antes dos últimos 4 dígitos
  if (valor.length > 10) {
    valor = valor.slice(0, 10) + '-' + valor.slice(10, 14);// "(11) 98765" → "(11) 98765-4321"
  }

  // Limita a 15 caracteres  (formato completo)

  valor = valor.slice(0, 15);

  e.target.value = valor.slice(0, 15); // Atualiza campo com valor formatado
});

// ============================================
// RESUMO DO FUNCIONAMENTO
// ============================================

// NAVEGAÇÃO:
// 1. Página carrega → Mostra LOGIN
// 2. Clica "Criar conta" → Esconde LOGIN, Mostra CADASTRO
// 3. Clica "Voltar" → Esconde CADASTRO, Mostra LOGIN
// 4. Clica "Avançar" → Esconde LOGIN, Mostra CADASTRO

// MÁSCARA DE TELEFONE - EXEMPLO:
// Digita: "1"          → Campo mostra: "(1"
// Digita: "11"         → Campo mostra: "(11"
// Digita: "119"        → Campo mostra: "(11) 9"
// Digita: "11987654"   → Campo mostra: "(11) 98765"
// Digita: "1198765432" → Campo mostra: "(11) 98765-432"
// Digita: "11987654321"→ Campo mostra: "(11) 98765-4321"