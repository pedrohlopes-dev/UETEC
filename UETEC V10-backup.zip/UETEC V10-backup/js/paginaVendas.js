// Função para atualizar os contadores de ambos os carrinhos (mobile e desktop)
function updateBothCartCounts(count) {
    const cartCount = document.getElementById('cart-count'); // contador desktop
    const cartCountMobile = document.getElementById('cart-count-mobile'); // contador mobile
    
    if (cartCount) cartCount.textContent = count; // atualiza desktop se existir
    if (cartCountMobile) cartCountMobile.textContent = count; // atualiza mibile se existir
}

// Fazer ambos os botões do carrinho funcionarem
// aguarda html carregar completamente
document.addEventListener('DOMContentLoaded', function() {
    const cartButton = document.getElementById('cartButton'); // botão desktop
    const cartButtonMobile = document.getElementById('cartButtonMobile'); // botão mobile
    const cartModal = document.getElementById('cartModal'); // modal do carrinho
    
    // Função para abrir o modal do carrinho
    function openCart() {
        cartModal.style.display = 'block'; // torna modal visivel
        renderCartItems(); // renderiza produtos do carrinho
    }
    
    // Configurar ambos os botões

    // adiciona evento de clique no botão desktop
    if (cartButton) {
        cartButton.addEventListener('click', openCart);
    }

    // adiciona evento de clique no botão mobile
    if (cartButtonMobile) {
        cartButtonMobile.addEventListener('click', openCart);
    }
});

/*DICA 01: INICIO CLASSE DO MENU RESPONSIVO E PROPRIEDADES*/
class NavegacaoMobile {
    // constructor: inicializa propriedadea da classe
    constructor(menuResponsivo, menuTopo, menuLinks) {
        this.menuResponsivo = document.querySelector(menuResponsivo); // botão hambueguer
        this.menuTopo = document.querySelector(menuTopo); // menu que abre/fecha
        this.menuLinks = document.querySelectorAll(menuLinks); // links do menu
        this.classeAtivo = "ativo"; // nome da classe css para menu aberto
        this.handleClick = this.handleClick.bind(this); // vincula contexto
    }
    
    // alterna estado do menu (abre/fecha)
    handleClick() {
        this.menuTopo.classList.toggle(this.classeAtivo); // toggle no menu 
        this.menuResponsivo.classList.toggle(this.classeAtivo); // toggle no botão
    }
    // adiciona evento de clique no botão hamburguer
    addClickEvent() {
        this.menuResponsivo.addEventListener("click", this.handleClick);
    }

    init() { // inicializa o menu mobile 
        if (this.menuResponsivo) { // se o elemento existe
            this.addClickEvent(); // ativa evento
        }
        return this; // retorna a própria instância (permite encadeamento)
    }
}
// cria instância do menu mobile com os seletores css 
const navegacaoMobile = new NavegacaoMobile(
    ".menu-responsivo", // botão hambueguer
    ".menu-topo", // menu
    ".menu-topo li" //itens do menu
);

navegacaoMobile.init(); // inicializa menu
/*DICA 01: FIM CLASSE DO MENU RESPONSIVO E PROPRIEDADES*/

/* === CARROSSEL === */
const track = document.querySelector(".carousel-track"); // conteiner dos slides
const slides = Array.from(track.children); // array com todos os slides
const nextButton = document.querySelector(".next"); // botão próximo
const prevButton = document.querySelector(".prev"); // botão anterior 
const indicators = document.querySelectorAll(".carousel-indicator"); // bolinhas indicadoras
let currentIndex = 0; // indice do slide atual

// atualiza posicao do carrossel e indicadores
function updateCarousel() {

    // move o carrossel (trasnlateX desloca horizontalmente)
    track.style.transform = `translateX(-${currentIndex * 100}%)`;

    // atualiza classe active nos indicadores
    indicators.forEach((dot, i) => {
        dot.classList.toggle("active", i === currentIndex);
    });
}

//botao proximo: avança slide (volta ao primeiro quando chegar ao ultimo)
nextButton.addEventListener("click", () => {
    currentIndex = (currentIndex + 1) % slides.length; // % faz voltar ao inicio
    updateCarousel();
});

// botao anterior: volta slide (vai pro ultimo quando estiver no primeiro)
prevButton.addEventListener("click", () => {
    currentIndex = (currentIndex - 1 + slides.length) % slides.length;
    updateCarousel();
});

// indicadores: clica na bolinha e vai pro slide correspondente
indicators.forEach((dot, i) => {
    dot.addEventListener("click", () => {
        currentIndex = i;
        updateCarousel();
    });
}); 

// === MODAL DO CARRINHO ===
const cartModal = document.getElementById("cartModal");  // modal do carrinho
const fecharCarrinho = document.querySelector(".fechar-carrinho");// botão x
const cartItemsContainer = document.getElementById("cartItems"); // onde ficam os produtos
const cartTotalElem = document.getElementById("cartTotal"); // total em reais
const cartButton = document.getElementById("cartButton"); // botão carrinho
const cartCount = document.getElementById("cart-count"); // container de itens

let cart = []; // Array que guarda produtos no carrinho

function updateCartCount() {
    //reduce() Soma TODAS as quantidades do carrinho
    // sum = acumulador, item = produto atual, 0 = valor inicial
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    
    cartCount.textContent = totalItems; // atualiza contador desktop

    const cartCountMobile = document.getElementById('cart-count-mobile');
    if (cartCountMobile) {
        cartCountMobile.textContent = totalItems; // atualiza mobile
    }
}

// Fecha o modal ao clicar no x
fecharCarrinho.addEventListener("click", () => {
    cartModal.style.display = "none";
});

// Fecha ao clicar fora do modal (área escura)
window.addEventListener("click", (e) => {
    if (e.target === cartModal) { // se clicou no fundo
        cartModal.style.display = "none";
    }
});

// Renderiza os itens do carrinho
function renderCartItems() {
    cartItemsContainer.innerHTML = ""; // limpa lista anterior
    let total = 0; // acumulador do valor total

    // percorre cada produto do carrinho 
    cart.forEach((product, index) => {
        const item = document.createElement("div"); // cria div para o produto
        item.classList.add("cart-item"); // adiciona classe css

        //template html do item (img, nome, preço, quantidade, botao remover)
        item.innerHTML = `
            <img src="${product.image}" alt="${product.name}" style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px; margin-right: 10px;">
            <div style="flex: 1;">
                <strong>${product.name}</strong><br>
                <span style="color: #666; font-size: 0.9rem;">R$ ${product.price.toFixed(2)} x ${product.quantity}</span>
            </div>
            <div style="text-align: right;">
                <strong style="color: #AB0D0D;">R$ ${(product.price * product.quantity).toFixed(2)}</strong><br>
                <img src="../imagens/icones/lixeira.png" height="15px" width="15px" class="remove-item" data-index="${index}" style="cursor: pointer; margin-top: 5px;">
            </div>
        `;
        cartItemsContainer.appendChild(item); // adiciona item na lista
        total += product.price * product.quantity; // soma ao total
    });

    cartTotalElem.textContent = total.toFixed(2); // atualiza valor total
    updateCartCount(); // atualiza contador de itens
}

// LÓGICA DO BOTÃO FINALIZAR PEDIDO
document.addEventListener('DOMContentLoaded', function() {
    const checkoutButton = document.getElementById('checkoutButton');

    if (checkoutButton) {
        checkoutButton.addEventListener('click', async (event) => {
            // 1. Impedir a navegação padrão do link (IMPEDE O REDIRECIONAMENTO IMEDIATO)
            event.preventDefault(); 

            // Verificar se o carrinho está vazio antes de continuar
            if (cart.length === 0) {
                alert("Seu carrinho está vazio. Adicione produtos antes de finalizar o pedido.");
                return;
            }
            
            // 2. Enviar o carrinho (JS array) para o PHP Session via AJAX
            try {
                // Note o caminho: 'php/processarCarrinho.php'
                const response = await fetch('processarCarrinho.php', {
                    method: 'POST', // envia dados
                    headers: {
                        'Content-Type': 'application/json' // formato JSON
                    },
                    body: JSON.stringify(cart) // converte array em json
                });

                const result = await response.json(); // converte resposta em objeto

                if (result.success) {
                    // 3. Se o servidor confirmou o salvamento na sessão, AGORA SIM, redirecionar
                    window.location.href = checkoutButton.href; 
                } else {
                    alert('Erro ao processar o carrinho no servidor: ' + (result.message || 'Resposta inválida.'));
                }

            } catch (error) {
                console.error('Erro na comunicação com o servidor:', error);
                alert('Ocorreu um erro de rede. Tente novamente.');
            }
        });
    }

});

// Botão de remoção individual
// Delega evento: captura clique em qualquer elemento com classe 'remove-item'
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('remove-item')) {
        const index = parseInt(e.target.getAttribute('data-index')); // pega índice do produto
        cart.splice(index, 1); // remove 1 item no posição 'index'
        renderCartItems(); // atualiza visual
    }
});

// Botão limpar carrinho
document.addEventListener('DOMContentLoaded', function() {
    const clearCartBtn = document.getElementById('clearCartButton');
    if (clearCartBtn) {
        clearCartBtn.addEventListener('click', function() {
            cart = []; // esvazia array
            renderCartItems(); // atualiza visual
        });
    }
});

// === MODAL DE DETALHES DO PRODUTO ===

const productModal = document.getElementById("productModal"); // modal grande do produto
const closeProductModal = document.querySelector(".close-product-modal"); // botão x
let currentProduct = null; // produto atualmente sendo visualizado
let selectedSize = null; // tamanho selecionado pelo usuario

// Função para abrir o modal com detalhes do produto
function openProductModal(productElement) {

    // extrai dados do elemento html (atributos data-*)
    currentProduct = {
        id: parseInt(productElement.dataset.id),
        name: productElement.dataset.name,
        price: parseFloat(productElement.dataset.price),
        stock: parseInt(productElement.dataset.stock),
        image: productElement.dataset.image,
        description: productElement.dataset.description || "Produto de alta qualidade, feito com materiais selecionados para garantir conforto e durabilidade.",
        sizes: productElement.dataset.sizes ? productElement.dataset.sizes.split(',') : ['P', 'M', 'G', 'GG']
    };
    
    // Preencher informações do modal
    document.getElementById('modalProductName').textContent = currentProduct.name;
    document.getElementById('modalMainImage').src = currentProduct.image;
    document.getElementById('modalMainImage').alt = currentProduct.name;
    
    // Preço
    // calcula e exibe preço antigo (19%  mais caro)
    const oldPrice = (currentProduct.price * 1.19).toFixed(2);
    document.getElementById('modalOldPrice').textContent = `R$ ${oldPrice.replace('.', ',')}`;
    document.getElementById('modalCurrentPrice').textContent = `R$ ${currentProduct.price.toFixed(2).replace('.', ',')}`;
    
    // Parcelamento (exemplo: 12x)
    //calcula parcelamento 12X
    const installmentValue = (currentProduct.price / 12).toFixed(2);
    document.getElementById('modalInstallments').textContent = 
        `R$ ${currentProduct.price.toFixed(2).replace('.', ',')} em até 12x de R$ ${installmentValue.replace('.', ',')}`;
    
    // Descrição do produto
    document.getElementById('modalDescription').textContent = currentProduct.description;
    
    // Tamanhos disponíveis
    // renderiza botoes de tamanho
    const sizesContainer = document.getElementById('modalSizes');
    sizesContainer.innerHTML = ''; // limpa tamanhos anteriores
    selectedSize = null; // reset selecao
    
    currentProduct.sizes.forEach(size => {
        const sizeBtn = document.createElement('button');
        sizeBtn.className = 'product-size-option';
        sizeBtn.textContent = size.trim();
        sizeBtn.onclick = () => selectSize(sizeBtn, size.trim()); // ao clicar, seleciona
        sizesContainer.appendChild(sizeBtn);
    });
    
    // Estoque
    // atualiza informacoes de estoque
    updateModalStock();
    
    // Resetar quantidade para 1
    document.getElementById('modalQuantity').value = 1;
    
    // Mostrar modal em trava scroll da página
    productModal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

// Função para selecionar tamanho
function selectSize(btn, size) {
    // remove classe 'selected' de todos os botões
    document.querySelectorAll('.product-size-option').forEach(b => {
        b.classList.remove('selected');
    });
    btn.classList.add('selected'); // adiciona no botão clicado
    selectedSize = size; // guarda tamanho selecionado
}

// Atualizar informações de estoque
function updateModalStock() {
    const stockContainer = document.getElementById('modalStock');
    const stockText = document.getElementById('modalStockText');
    
    // estoque alto: mais de 10 unidades
    if (currentProduct.stock > 10) {
        stockContainer.className = 'product-modal-stock';
        stockText.textContent = `${currentProduct.stock} unidades disponíveis`;
    } else if (currentProduct.stock > 0) { // baixo: 1 e 10 unidades
        stockContainer.className = 'product-modal-stock low-stock';
        stockText.textContent = `Apenas ${currentProduct.stock} unidades restantes!`;
    } else { // sem estoque
        stockContainer.className = 'product-modal-stock out-of-stock';
        stockText.textContent = 'Produto esgotado';
    }
}

// Controles de quantidade
// botão de diminuir quantidade
document.getElementById('decreaseQty').addEventListener('click', () => {
    const input = document.getElementById('modalQuantity');
    const currentValue = parseInt(input.value);
    if (currentValue > 1) { // minimo é 1
        input.value = currentValue - 1;
    }
});

// botão aumentar quantidade
document.getElementById('increaseQty').addEventListener('click', () => {
    const input = document.getElementById('modalQuantity');
    const currentValue = parseInt(input.value);
    if (currentValue < currentProduct.stock) { // não pode passar do estoque
        input.value = currentValue + 1;
    } else {
        alert(`Estoque máximo disponível: ${currentProduct.stock} unidades`);
    }
});

// Adicionar ao carrinho pelo modal
document.getElementById('modalAddToCart').addEventListener('click', () => {
    // valido se tamanho foi selecionado
    if (!selectedSize) {
        alert('Por favor, selecione um tamanho!');
        return;
    }
    
    const quantity = parseInt(document.getElementById('modalQuantity').value);
    
    // se existir, aumenta quantidade
    const existingProduct = cart.find(item => 
        item.id === currentProduct.id && item.size === selectedSize
    );
    
    if (existingProduct) {
        const newQuantity = existingProduct.quantity + quantity;
        if (newQuantity <= currentProduct.stock) {
            existingProduct.quantity = newQuantity;
            alert(`${quantity} unidade(s) adicionada(s)! Total: ${existingProduct.quantity}`);
        } else {
            alert(`Estoque insuficiente! Disponível: ${currentProduct.stock} unidades`);
            return;
        }
    } else {
        // se ñ existe, adiciona novo produto
        cart.push({
            id: currentProduct.id,
            name: `${currentProduct.name} (Tamanho ${selectedSize})`,
            price: currentProduct.price,
            quantity: quantity,
            stock: currentProduct.stock,
            image: currentProduct.image,
            size: selectedSize
        });
        alert(`${quantity} unidade(s) adicionada(s) ao carrinho!`);
    }
    
    updateCartCount(); // atualiza contador
    renderCartItems(); // atualiza visual do carrinho
    productModal.style.display = 'none'; // fecha modal
    document.body.style.overflow = 'auto'; // libera scroll
});

// Fechar modal
// fechar pelo botão x
closeProductModal.addEventListener('click', () => {
    productModal.style.display = 'none';
    document.body.style.overflow = 'auto'; // libera scroll
});

// Fechar ao clicar fora do modal do produto
window.addEventListener('click', (e) => {
    if (e.target === productModal) {
        productModal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
});

// === CLIQUE NOS PRODUTOS ABRE O MODAL ===
const products = document.querySelectorAll(".product"); // todos os cards de produto

products.forEach((productElement) => {
    // funçao que abre o modal
    const openModal = () => {
        openProductModal(productElement);
    };

    // adiciona evento de clique em 3 partes do card
    productElement.querySelector(".product-img").addEventListener("click", openModal); // imagem
    productElement.querySelector(".product-name").addEventListener("click", openModal); // nome
    productElement.querySelector(".product-price").addEventListener("click", openModal); // preço
});
