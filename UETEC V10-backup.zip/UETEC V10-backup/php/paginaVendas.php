<?php
// inicia a sessão
session_start();

// verifica se o usuário está logado
if (!isset($_SESSION['log']) || $_SESSION['log'] !== 'ativo') {
    // se não estiver, redireciona o usuário para a página de login
    echo "<script> window.location.href='../paginaLogin.html';</script>";
    exit;
}

// carrega o arquivo que contém as informações para conectar ao banco de dados
require_once 'conexao.php';

// inicia a conexão com o banco de dados
$bd = new BancodeDados();
$bd->conecta();

// DICA 01: BUSCA DE PRODUTOS PARA MOSTRAR

// busca todos os produtos que ainda têm unidades em estoque (maior que zero)
// junta os dados do produto com o nome da categoria dele
$query_produtos = "SELECT p.*, c.nome as categoria_nome 
                   FROM produtos p 
                   LEFT JOIN categorias c ON p.id_categoria = c.id_categoria 
                   WHERE p.estoque > 0 
                   ORDER BY p.id_produto DESC";

// DICA 02: BUSCA E ARMAZENAMENTO

// envia o comando de busca para o banco de dados
$resultado = mysqli_query($bd->con, $query_produtos);
$produtos = [];

// verifica se a busca deu certo
if ($resultado) {
    // transforma as linhas encontradas no banco em um formato que o php consegue entender
    while ($row = mysqli_fetch_assoc($resultado)) {
        $produtos[] = $row;
    }
}

// DICA 03: SEPARAÇÃO DE PRODUTOS PARA EXIBIÇÃO

// pega os 4 primeiros produtos para mostrar em um destaque especial
$produtos_selecionados = array_slice($produtos, 0, 4);
// pega o resto dos produtos para mostrar em uma lista normal
$produtos_ultimos = array_slice($produtos, 4);

// fecha a porta de comunicação com o banco de dados
$bd->fechar();
?>

<!DOCTYPE html> <!-- paginaVendas.php -->
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loja | UEtec</title>
    <link rel="stylesheet" href="../css/paginaVendas.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="../imagens/logo.png">
</head>
<body>
    <!--DICA 01: INICIO MENU RESPONSIVO-->
    <header>
        <nav>
            <a class="logo" href="../index.html">UEtec</a>
            <ul class="menu-topo">
                <li><a href="../index.html #link3">Fale conosco</a></li>
                <li><a href="meusPedidos.php">Meus Pedidos</a></li>
                <li class="cart-desktop"><a href="javascript:void(0)" id="cartButton"><img src="../imagens/icones/cesto.svg" alt="" height="25px" width="25px"><span id="cart-count">0</span></a></li>
                <li><a href="fecharSessao.php" class="entrar">Sair</a></li>
            </ul>
            
            <!-- NOVO: Carrinho fixo para mobile -->
            <div class="cart-fixed-mobile">
                    <a href="javascript:void(0)" id="cartButtonMobile"><img src="../imagens/icones/cesto.svg" alt="" height="25px" width="25px"><span id="cart-count-mobile">0</span></a>
            </div>

            <!--inicio da respondividade/menu hamburguer-->
            <div class="menu-responsivo">
                <div class="linha1"></div>
                <div class="linha2"></div>
                <div class="linha3"></div>
            </div>
            <!--fim da responsividade/menu hamburguer-->
        </nav>
    </header>

    <!-- MODAL DO CARRINHO -->
<div id="cartModal" class="cart-modal">
    <div class="cart-modal-content">
        <div class="tituloBotaoCarrinho">
            <p class="tituloCarrinho">Carrinho de compras</p>
            <a class="fechar-carrinho">&times;</a>
    </div>

    <div id="masterCard">
        <div id="cartItems">
        <!-- Aqui os produtos adicionados serão listados via JS -->
        </div>
    </div>
    
        <p class="totalCarrinho">Total: R$ <span id="cartTotal">0.00</span></p>

        <div class="containerCompra">
        <a id="checkoutButton" href="finalizarPedido.php">Finalizar Pedido</a>
        <button id="clearCartButton" class="remove-item">Limpar</button>
        </div>
    </div>
</div>

<!-- MODAL DE DETALHES DO PRODUTO -->
<div id="productModal" class="product-modal">
    <div class="product-modal-content">
        <div class="product-modal-header">
            <span class="close-product-modal">&times;</span>
        </div>
        
        <div class="product-modal-body">
            <!-- Seção da Imagem -->
            <div class="product-modal-image-section">
                <img id="modalMainImage" src="" alt="" class="product-modal-main-image">
            </div>
            
            <!-- Seção de Informações -->
            <div class="product-modal-info-section">
                <h2 id="modalProductName" class="product-modal-title"></h2>
                
                <div class="product-modal-rating">
                    <span class="product-modal-stars">★★★★☆</span>
                    <span class="product-modal-reviews" id="modalReviews">25 avaliações</span>
                </div>
                
                <div class="product-modal-price-section">
                    <span id="modalOldPrice" class="product-modal-old-price"></span>
                    <span class="product-modal-discount">16%</span>
                </div>
                
                <div>
                    <div id="modalCurrentPrice" class="product-modal-current-price"></div>
                    <div class="product-modal-installments">no Pix</div>
                    <div id="modalInstallments" class="product-modal-installments"></div>
                </div>
                
                <p id="modalDescription" class="product-modal-description"></p>
                
                <!-- Seleção de Tamanho -->
                <div class="product-modal-size-section">
                    <label class="product-modal-size-label">Tamanho:</label>
                    <div id="modalSizes" class="product-modal-sizes">
                        <!-- Tamanhos serão inseridos via JS -->
                    </div>
                </div>
                
                <!-- Estoque -->
                <div id="modalStock" class="product-modal-stock">
                    <span>✓</span>
                    <span id="modalStockText"></span>
                </div>
                
                <!-- Quantidade -->
                <div class="product-modal-quantity-section">
                    <span class="product-modal-quantity-label">Quantidade:</span>
                    <div class="product-modal-quantity-controls">
                        <button class="quantity-btn" id="decreaseQty">-</button>
                        <input type="number" id="modalQuantity" class="quantity-input" value="1" min="1" readonly>
                        <button class="quantity-btn" id="increaseQty">+</button>
                    </div>
                </div>
                
                <!-- Botão Adicionar ao Carrinho -->
                <button id="modalAddToCart" class="product-modal-add-to-cart">
                    <span>🛒</span>
                    <span>Adicionar ao Carrinho</span>
                </button>
            </div>
        </div>
    </div>
</div>

    <div class="container1">
  <!-- === CARROSSEL === -->
  <div class="carousel">
    <!-- Área que contém os slides -->
    <div class="carousel-track">
      <div class="carousel-slide slide1">
    <picture>
        <source media="(max-width: 768px)" srcset="../imagens/slide_1.png">
        <img src="../imagens/slide-1.png" alt="" height="700px" width="1200px">
    </picture>
</div>

      <div class="carousel-slide slide2">
    <picture>
        <source media="(max-width: 768px)" srcset="../imagens/slide_2.png">
        <img src="../imagens/slide-2.png" alt="" height="700px" width="1175px">
    </picture>
</div>

      <div class="carousel-slide slide3">
    <picture>
        <source media="(max-width: 768px)" srcset="../imagens/slide_3.png">
        <img src="../imagens/slide-3.png" alt="" height="700px" width="1175px">
    </picture>
</div>

    </div>

    <!-- Botões de navegação -->
    <button class="carousel-button prev">&#10094;</button>
    <button class="carousel-button next">&#10095;</button>

    <!-- Bolinhas de navegação -->
    <div class="carousel-nav">
      <div class="carousel-indicator active"></div>
      <div class="carousel-indicator"></div>
      <div class="carousel-indicator"></div>
    </div>
  </div>
  </div>

<!-- SEÇÃO 1: PRODUTOS SELECIONADOS -->
<div class="page-inner-content">
    <p class="section-title">Produtos em destaque</p>
    <div class="subtitle-underline"> </div>
    <div class="cols cols-4">
        <?php if (count($produtos_selecionados) > 0): ?>
            <?php foreach ($produtos_selecionados as $produto): ?>
                <div class="product add-cart" 
                     data-id="<?php echo $produto['id_produto']; ?>"
                     data-name="<?php echo htmlspecialchars($produto['nome']); ?>"
                     data-price="<?php echo number_format($produto['preco'], 2, '.', ''); ?>"
                     data-stock="<?php echo $produto['estoque']; ?>"
                     data-image="<?php echo htmlspecialchars($produto['imagem_url'] ?? '../imagens/uniformeAzulOriginal.webp'); ?>"
                     data-description="<?php echo htmlspecialchars($produto['descricao']); ?>"
                     data-sizes="<?php echo htmlspecialchars($produto['tamanhos_disponiveis'] ?? 'P,M,G,GG'); ?>">
                    
                    <img src="<?php echo htmlspecialchars($produto['imagem_url'] ?? '../imagens/uniformeAzulOriginal.webp'); ?>" 
                         alt="<?php echo htmlspecialchars($produto['nome']); ?>" 
                         class="product-img">
                    <p class="product-name"><?php echo htmlspecialchars($produto['nome']); ?></p>
                    <p class="rate">&#9733;&#9733;&#9734;&#9734;&#9734;</p>
                    <p class="product-price">R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                    <p class="product-stock">Estoque: <?php echo $produto['estoque']; ?> unidades</p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p style="grid-column: 1/-1; text-align: center; padding: 20px;">Nenhum produto disponível no momento.</p>
        <?php endif; ?>
    </div>
</div>

<!-- SEÇÃO 2: ÚLTIMOS PRODUTOS -->
<div class="page-inner-content">
    <h2 class="section-title">Mais +</h2>
    <div class="subtitle-underline"> </div>
    
    <?php if (count($produtos_ultimos) > 0): ?>
        <div class="cols cols-4">
            <?php foreach ($produtos_ultimos as $produto): ?>
                <div class="product add-cart" 
                     data-id="<?php echo $produto['id_produto']; ?>"
                     data-name="<?php echo htmlspecialchars($produto['nome']); ?>"
                     data-price="<?php echo number_format($produto['preco'], 2, '.', ''); ?>"
                     data-stock="<?php echo $produto['estoque']; ?>"
                     data-image="<?php echo htmlspecialchars($produto['imagem_url'] ?? '../imagens/uniformeAzulOriginal.webp'); ?>"
                     data-description="<?php echo htmlspecialchars($produto['descricao']); ?>"
                     data-sizes="<?php echo htmlspecialchars($produto['tamanhos_disponiveis'] ?? 'P,M,G,GG'); ?>">
                    
                    <img src="<?php echo htmlspecialchars($produto['imagem_url'] ?? '../imagens/uniformeAzulOriginal.webp'); ?>" 
                         alt="<?php echo htmlspecialchars($produto['nome']); ?>" 
                         class="product-img">
                    <p class="product-name"><?php echo htmlspecialchars($produto['nome']); ?></p>
                    <p class="rate">&#9733;&#9733;&#9734;&#9734;&#9734;</p>
                    <p class="product-price">R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                    <p class="product-stock">Estoque: <?php echo $produto['estoque']; ?> unidades</p>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p style="text-align: center; padding: 20px; color: #666;">Sem mais produtos no momento.</p>
    <?php endif; ?>
</div>

        <footer class="footer">
            <div class="bloco1Footer">
                © 2025 3° Informática para a Internet
            </div>

            <div class="bloco2Footer">
                        <a href="../politicaPrivacidade.html" class="politicaFooter">Política de privacidade</a>
                        <span class="politicaFooter">-</span>
                        <a href="../politicaReembolso.html" class="politicaFooter">Política de reembolso</a>
            </div>
        </footer>

  <script src="../js/paginaVendas.js"></script>
</body>
</html>
