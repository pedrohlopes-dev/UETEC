<?php
// inicia a sessão
session_start();

// verifica se o usuário esta logado
if (!isset($_SESSION['log']) || $_SESSION['log'] !== 'ativo') {
    // se não estiver, avisa e redireciona o usuário para a página de login
    echo "<script> window.location.href='../paginaLogin.html';</script>";
    exit;
}

// DICA 01: VERIFICAÇÃO DO CARRINHO DE COMPRAS

// verifica se o array do carrinho não existe na sessão ou se está vazio
if (!isset($_SESSION['carrinho_pedido']) || empty($_SESSION['carrinho_pedido'])) {
    // se não houver itens no carrinho, redireciona para a página de vendas
    echo "<script> window.location.href='paginaVendas.php';</script>";
    // para a execução do código aqui
    exit;
}

// DICA 02: PREPARAÇÃO DA VARIÁVEL

// armazena o array do carrinho da sessão em uma variável local para facilitar o uso no restante do script
$carrinho_pedido = $_SESSION['carrinho_pedido'];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirme o seu pedido | UEtec</title>
    <link rel="stylesheet" href="../css/finalizarPedido.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="../imagens/logo.png">
</head>
<body>
    <!--DICA 01: INICIO MENU RESPONSIVO-->
    <header>
        <nav>
            <a class="logo" href="../index.html">UEtec</a>
            <!--inicio da respondividade/menu hamburguer-->
            <div class="menu-responsivo">
                <div class="linha1"></div>
                <div class="linha2"></div>
                <div class="linha3"></div>
            </div>
            <!--fim da responsividade/menu hamburguer-->
            <ul class="menu-topo">
                <li><a href="../index.html #link3">Fale conosco</a></li>
                <li><a href="paginaVendas.php" class="entrar">Voltar</a></li>
            </ul>
        </nav>
    </header>
    <!--DICA 01: FIM MENU RESPONSIVO-->

    <!--DICA 02: INICIO DO CONTAINER 1-->
    <section class="container1">
        <div class="bloco1Container1">
            <p class="tituloContainer1" style="text-align: center; margin-top: 25px;">Confirme se os itens abaixo estão corretos:</p>

            <div class="corItems">
                <div class="masterCard">
    <?php
        $total = 0;
        foreach ($carrinho_pedido as $item) {
            $total += floatval($item['price']);
            echo "<div class='item-pedido'>"; 
            echo "<p>{$item['name']} - R$ {$item['price']}</p>";
            echo "</div>"; 
        }
        ?>
        </div>
        
        <p class="totalCarrinho">Total: R$ <?php echo number_format($total, 2, '.', ','); ?></p>

        </div>
        
        <div class="opcoesFundo">
        <form action="salvarPedido.php" method="POST">
            <button type="submit" id="finalizarPedido">Confirmar</button>
         </form>
        <a class="entrar" href="paginaVendas.php">Cancelar</a>
        </div>

        </div>

    </section>

    <!--DICA 02: FIM DO CONTAINER 1-->

    <script src="../js/paginaVendas.js"></script>
</body>
</html>