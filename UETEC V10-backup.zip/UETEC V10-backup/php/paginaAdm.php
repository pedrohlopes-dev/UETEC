<?php
// inicia a sessão
session_start();

// verifica se o usuario esta logado
if (!isset($_SESSION['log']) || $_SESSION['log'] !== 'ativo') {

    // se não estiver, avisa e redireciona o usuário para a página de login
    echo "<script> window.location.href='../paginaLogin.html';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Loja | UEtec</title>
  <link rel="stylesheet" href="../css/paginaAdm.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <link rel="icon" type="image/png" href="../imagens/logo.png" />
</head>
<body>
  <main class="painel">
    <aside class="menu-lateral">
  <ul>
    <li><a class="logo" href="#">UEtec</a></li>
    <li><a href="#status-produtos" class="secao" data-target="dashboard">📦 Dashboard</a></li>
    <li><a href="#status-produtos" class="secao" data-target="status-produtos">⚙️ Status dos Produtos</a></li>
    <li><a href="#edicao-estoque" class="secao" data-target="comfigurar-produtos">🔨 Configurar produtos</a></li>
    <li><a href="#edicao-nome" class="secao" data-target="edicao-nome">🗒️ Editar Produto</a></li>
    <li><a href="#relatorio-vendas" class="secao" data-target="relatorio-vendas">📈 Relatório de Vendas</a></li>
    <li><a href="#edicao-estoque" class="secao" data-target="pedidos">📫 Pedidos</a></li>
    <li><a href="#edicao-estoque" class="secao" data-target="edicao-estoque">👕 Edição de Estoque</a></li>
    <li><a href="fecharSessao.php" class="entrar">Sair</a></li>
  </ul>
</aside>

    <section class="conteudo-principal">
      <div id="dashboard" class="secao-conteudo escondido">
        <h1>Dashboard</h1>
        <p>Visão geral e resumos rápidos do desempenho da loja.</p>
        <div class="secao-gerenciamento">
          <h3>Resumo da Atividade</h3>
          <p>Pedidos recentes: 12 novos pedidos</p>
          <p>Faturamento do dia: R$ 1.500,00</p>
          <p>Acessos à página hoje: 450</p>
        </div>
      </div>

      <div id="status-produtos" class="secao-conteudo">
        <h1>Status dos Produtos</h1>
        <p>Gerencie o status atual de todos os uniformes disponíveis.</p>
        <div class="secao-gerenciamento">
          <h3>Lista de Uniformes</h3>
          <table>
            <thead>
              <tr>
                <th>Nome do Uniforme</th>
                <th>Status</th>
                <th>Última Atualização</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Camiseta Azul Marinho</td>
                <td>399 Em Estoque</td>
                <td>14/09/2025</td>
              </tr>
              <tr>
                <td>Moletom Azul Marinho</td>
                <td>Fora de Estoque</td>
                <td>12/09/2025</td>
              </tr>
              <tr>
                <td>Camisa Branca</td>
                <td>Fora de Estoque</td>
                <td>12/09/2025</td>
              </tr>
              <tr>
                <td>Calça Azul Marinho</td>
                <td>37 Em Estoque</td>
                <td>12/09/2025</td>
              </tr>
              <tr>
                <td>Camisa Preta</td>
                <td>Fora de Estoque</td>
                <td>12/09/2025</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div id="comfigurar-produtos" class="secao-conteudo escondido">
        <h1>Configurar produtos</h1>
        <p>Configure ou remova produtos da loja virtual.</p>
        <div class="secao-gerenciamento">
              <h3>Novo Produto</h3>
          <form>
            <label for="novo-produto">Nome do Produto:</label>
            <input type="text" id="novo-produto" placeholder="Nome do Produto" required>
            
            <label for="descricao-novo-produto">Descrição:</label>
            <textarea id="descricao-novo-produto" placeholder="Descrição completa do produto"></textarea>
            
            <label for="preco-novo-produto">Preço:</label>
            <input type="number" id="preco-novo-produto" placeholder="R$ 0,00" step="0.01" required>
            
            <label for="estoque-novo-produto">Estoque Inicial:</label>
            <input type="number" id="estoque-novo-produto" placeholder="0" value="0" required>
            
            <label for="categoria-novo-produto">ID da Categoria:</label>
            <input type="number" id="categoria-novo-produto" placeholder="Ex: 1 (Opcional)"> 
            
            <label for="nova-imagem-produto">Imagem:</label>
            <input type='file' id="nova-imagem-produto">
            <button type="submit" class="botao-atualizar">Adicionar</button>
          </form>
        </div>
        <div class="secao-gerenciamento">
  <h3>Remover Produto</h3>
  <form id="form-remover">  
    <label for="remover-produto">Produto:</label>
    <input type="text" id="remover-produto" placeholder="Nome do Produto">
    <button type="submit" class="botao-atualizar">Remover</button>
  </form>
</div>
      </div>

      <div id="relatorio-vendas" class="secao-conteudo escondido">
        <h1>Relatório de Vendas</h1>
        <p>Visualize gráficos e dados sobre as vendas de uniformes.</p>
        <div class="secao-gerenciamento">
          <h3>Vendas Totais</h3>
          <p>Valor total de vendas nos últimos 30 dias: R$ 5.800,00</p>
          <p>Item mais vendido: Camisa Branca</p>
          <p>Item menos vendido: Camisa Azul Marinho</p>
        </div>
      </div>
      
      <div id="pedidos" class="secao-conteudo escondido">
        <h1>Pedidos</h1>
        <p>Visualize e gerencie os pedidos recebidos.</p>
        <div class="secao-gerenciamento">
          <h3>Lista de Pedidos Recentes</h3>
          <table>
            <thead>
              <tr>
                <th>Nº do Pedido</th>
                <th>Cliente</th>
                <th>Data</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>#98765</td>
                <td>João Silva</td>
                <td>18/09/2025</td>
                <td>Em processamento</td>
              </tr>
              <tr>
                <td>#98764</td>
                <td>Maria Souza</td>
                <td>17/09/2025</td>
                <td>Enviado</td>
              </tr>
              <tr>
                <td>#98763</td>
                <td>Carlos Almeida</td>
                <td>17/09/2025</td>
                <td>Concluído</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div id="edicao-estoque" class="secao-conteudo escondido">
        <h1>Edição de Estoque</h1>
        <p>Atualize a quantidade de itens no estoque e gerencie uniformes.</p>
        <div class="secao-gerenciamento">
          <h3>Atualizar Estoque</h3>
          <form>
            <label for="produto-estoque">Produto:</label>
            <input type="text" id="produto-estoque" placeholder="Nome do Produto">
            <label for="quantidade-estoque">Quantidade:</label>
            <input type="number" id="quantidade-estoque" placeholder="Nova Quantidade">
            <button type="submit" class="botao-atualizar">Atualizar</button>
          </form>
        </div>
      </div>

       <div id="edicao-nome" class="secao-conteudo escondido">
        <h1>Editar Produto</h1>
        <p>Atualize informações do produto.</p>
        <div class="secao-gerenciamento">
          <h3>Atualizar Nome</h3>
          <form>
            <label for="produto-nome">Nome do Produto:</label>
            <input type="text" id="produto-nome" placeholder="Nome atual do produto" required>
      
            <label for="novo-nome">Novo Nome:</label>
            <input type="text" id="novo-nome" placeholder="Digite o novo nome" required>
      
            <button type="submit" class="botao-atualizar">Atualizar</button>
          </form>
        </div>
        <div class="secao-gerenciamento">
         <h3>Atualizar Descrição</h3>
  <form id="form-descricao"> 
    <label for="produto-descricao">Nome do Produto:</label>
    <input type="text" id="produto-descricao" placeholder="Nome atual do produto">
    
    <label for="nova-descricao">Digite a nova descrição do produto:</label>
    <textarea id="nova-descricao" placeholder="Digite a nova descrição"></textarea>
    
    <button type="submit" class="botao-atualizar">Atualizar</button>
  </form>
        </div>

<div class="secao-gerenciamento">
  <h3>Atualizar Preço</h3>
  <form id="form-preco">
    <label for="produto-preco">Nome do Produto:</label>
    <input type="text" id="produto-preco" placeholder="Nome atual do produto" required>
    
    <label for="novo-preco">Novo Preço:</label>
    <input type="number" id="novo-preco" placeholder="R$ 0,00" step="0.01" required>
    
    <button type="submit" class="botao-atualizar">Atualizar</button>
  </form>
</div>

    <div class="secao-gerenciamento">
  <h3>Atualizar Imagem</h3>
  <form id="form-imagem">
    <label for="produto-imagem">Nome do Produto:</label>
    <input type="text" id="produto-imagem" placeholder="Nome atual do produto" required>
    
    <label for="nova-imagem">Nova Imagem:</label>
    <input type="file" id="nova-imagem" accept="image/*" required>
    
    <button type="submit" class="botao-atualizar">Atualizar</button>
  </form>
</div>

    </section>
  </main>

  <footer class="footer">
    <div class="bloco1Footer">© 2025 3° Informática para a Internet</div>
    <div class="bloco2Footer">
      <a href="../politicaPrivacidade.html" class="politicaFooter">Política de privacidade</a>
      <span class="politicaFooter">-</span>
      <a href="../politicaReembolso.html" class="politicaFooter">Política de reembolso</a>
    </div>
  </footer>

  <script src="../js/paginaAdm.js"></script>
</body>
</html>