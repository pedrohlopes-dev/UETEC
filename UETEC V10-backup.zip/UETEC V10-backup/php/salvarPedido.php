<?php
// DICA 01: INICIAR E VALIDAR SESSÃO

// inicia a sessão e a conexão com o banco de dados
session_start();
require_once('conexao.php');

// verifica se o usuário esta logado e se o carrinho de pedido não está vazio
if (!isset($_SESSION['log']) || $_SESSION['log'] !== 'ativo' || !isset($_SESSION['id_cliente']) || !isset($_SESSION['carrinho_pedido'])) {
    
    // se der erro, avisa e redireciona o usuário para a página de login
    echo "<script>alert('Sua sessão expirou ou o carrinho está vazio.'); window.location.href='../paginaLogin.html';</script>";
    exit;
}

$id_cliente = $_SESSION['id_cliente']; 
$carrinho_pedido = $_SESSION['carrinho_pedido'];

// instancia o objeto de conexão
$mysql = new BancodeDados();
$mysql->conecta();
$con = $mysql->con;

// DICA 02: INÍCIO DA TRANSAÇÃO COM BANCO DE DADOS

// inicia uma transação no banco de dados para garantir que todas as operações sejam completadas ou desfeitas em conjunto
mysqli_begin_transaction($con);

try {
    // valor total inicial
    $valor_total = 0;

    // pega cada item do carrinho para somar o valor final
    foreach ($carrinho_pedido as $item) {
        $preco_unitario = floatval($item['price']);
        $quantidade = intval($item['quantity']);

        // multiplica o preço pela quantidade e acumula o resultado no valor total
        $valor_total += $preco_unitario * $quantidade; 
    }

    $status_inicial = 'pendente';

    // DICA 03: INSERIR PEDIDO

    // prepara a instrução para inserir o pedido inicial na tabela pedidos
    $stmt_pedido = $con->prepare("INSERT INTO pedidos (id_cliente, total, status) VALUES (?, ?, ?)");
    // associa id_cliente, valor_total, status a instrução preparada
    $stmt_pedido->bind_param("ids", $id_cliente, $valor_total, $status_inicial);
    
    // executa a inserção e procura falhas
    if (!$stmt_pedido->execute()) {
        throw new Exception("erro ao inserir pedido: " . $stmt_pedido->error);
    }

    // obtém o id do pedido recém-criado para uso nas tabelas relacionadas
    $id_pedido = mysqli_insert_id($con);
    
    // gera um código de pedido único com base no id, data e um hash
    $data_atual = (new DateTime())->format('YmdHis'); 
    $codigo_pedido = strtoupper(substr(hash('md5', $id_pedido . $data_atual . $id_cliente . uniqid()), 0, 8));

    // atualiza o registro do pedido com o código gerado
    $stmt_update_pedido = $con->prepare("UPDATE pedidos SET codigo_pedido = ? WHERE id_pedido = ?");
    $stmt_update_pedido->bind_param("si", $codigo_pedido, $id_pedido);

    // executa a atualização e, em caso de erro, realiza o rollback e lança exceção
    if (!$stmt_update_pedido->execute()) {
        mysqli_rollback($con);
        throw new Exception("erro ao atualizar o código do pedido: " . $stmt_update_pedido->error);
    }
    
    // DICA 04: INSERÇÃO DE ITENS E ATUALIZAÇÃO DE ESTOQUE
    // prepara as instruções para inserir os itens do pedido e atualizar o estoque dos produtos
    $stmt_item = $con->prepare("INSERT INTO itens_pedido (id_pedido, id_produto, preco_unitario, quantidade) VALUES (?, ?, ?, ?)");
    $stmt_estoque = $con->prepare("UPDATE produtos SET estoque = estoque - ? WHERE id_produto = ?");

    // itera sobre cada item do carrinho
    foreach ($carrinho_pedido as $item) {
        // tipagem dos dados do carrinho
        $id_produto = intval($item['id']);
        $preco_unitario = floatval($item['price']);
        $quantidade = intval($item['quantity']);

        // insere o item na tabela itens_pedido
        $stmt_item->bind_param("iidi", $id_pedido, $id_produto, $preco_unitario, $quantidade);
        
        if (!$stmt_item->execute()) {
            throw new Exception("erro ao inserir item com id {$id_produto} no pedido: " . $stmt_item->error);
        }
        
        // atualiza o estoque do produto
        $stmt_estoque->bind_param("ii", $quantidade, $id_produto);
        if (!$stmt_estoque->execute()) {
            throw new Exception("erro ao atualizar estoque para o produto id {$id_produto}: " . $stmt_estoque->error);
        }
    }
    
    // DICA 05: FINALIZAR TRANSAÇÃO

    // se todas as operações forem completas com sucesso, confirma e torna as alterações permanentes
    mysqli_commit($con);
    
    // limpa o carrinho da sessão
    unset($_SESSION['carrinho_pedido']);
    
    // exibe mensagem de sucesso e redireciona o usuário
    echo "<script>alert('pedido finalizado com sucesso! seu código de pedido é: {$codigo_pedido} você será redirecionado para a página de meus pedidos'); window.location.href='meusPedidos.php';</script>";

} catch (Exception $e) {

    // DICA 06: TRATAMENTO DE ERROS E ROLLBACK

    // em caso de erro, desfaz a transação para restaurar o estado inicial do banco de dados
    mysqli_rollback($con);
    
    // registra o erro detalhado no log do servidor para análise do desenvolvedor
    error_log("erro ao salvar pedido: " . $e->getMessage());

    // aviso de erro e redirecionamento do usuario
    echo "<script>alert('erro ao finalizar pedido tente novamente mais tarde detalhes: " . addslashes($e->getMessage()) . "'); window.location.href='finalizarPedido.php';</script>";
}

// fecha a conexão com o banco de dados
$mysql->fechar();
?>