<?php
// DICA 01: CONTROLE DE SESSÃO E ACESSO

// inicia a sessão
session_start();

// verifica se o usuário esta logado
if (!isset($_SESSION['log']) || $_SESSION['log'] !== 'ativo' || !isset($_SESSION['id_cliente'])) {

   // se não estiver, avisa e redireciona o usuário para a página de login
    echo "<script> window.location.href='../paginaLogin.html';</script>";
    exit;
}

// DICA 02: CONEXÃO E PREPARAÇÃO

// carrega o arquivo que contém as informações para conectar ao banco de dados
require_once('conexao.php');

// armazena o id do cliente logado em uma variável local
$id_cliente = $_SESSION['id_cliente'];

// inicia a conexão com o banco de dados
$mysql = new BancodeDados();
$mysql->conecta();
$con = $mysql->con;

// prepara um array vazio para guardar todos os pedidos encontrados
$pedidos_cliente = [];

try {
    // DICA 03: BUSCA DE PEDIDOS

    // busca todos os pedidos feitos por este cliente, incluindo o status, valor total e o código único
    $query_pedidos = "
        SELECT
            id_pedido, 
            data_pedido, 
            status, 
            total,
            codigo_pedido
        FROM 
            pedidos
        WHERE 
            id_cliente = ?
        ORDER BY 
            data_pedido DESC
    ";

    // prepara a consulta para segurança contra invasão
    $stmt_pedidos = $con->prepare($query_pedidos);
    // associa o id do cliente a consulta
    $stmt_pedidos->bind_param("i", $id_cliente);
    // faz a busca
    $stmt_pedidos->execute();
    $result_pedidos = $stmt_pedidos->get_result();

    // DICA 04: ITERAÇÃO SOBRE OS PEDIDOS ENCONTRADOS

    // inicia um laço para processar cada pedido individualmente
    while ($pedido = $result_pedidos->fetch_assoc()) {
        $id_pedido = $pedido['id_pedido'];
        
        // ajusta a ordem da data do pedido
        $data_formatada = (new DateTime($pedido['data_pedido']))->format('d/m/Y H:i');
        $pedido['data_pedido'] = $data_formatada;
        
        // DICA 05: BUSCA DOS ITENS DE CADA PEDIDO

        // busca todos os itens (produtos, quantidade e preço) que pertencem ao pedido atual
        $query_itens = "
            SELECT
                ip.quantidade,
                ip.preco_unitario,
                prod.nome AS nome_produto
            FROM 
                itens_pedido ip
            INNER JOIN 
                produtos prod ON ip.id_produto = prod.id_produto
            WHERE 
                ip.id_pedido = ?
        ";
        
        // prepara a nova consulta para buscar os itens
        $stmt_itens = $con->prepare($query_itens);

        // associa o id do pedido atual a consulta
        $stmt_itens->bind_param("i", $id_pedido);
        $stmt_itens->execute();
        $result_itens = $stmt_itens->get_result();
        
        // cria um array para guardar a lista de itens dentro do pedido
        $pedido['itens'] = [];
        
        // adiciona cada item encontrado a lista de itens do pedido atual
        while ($item = $result_itens->fetch_assoc()) {
            $pedido['itens'][] = $item;
        }
        
        // adiciona o pedido completo (com a lista de itens dentro) no array final
        $pedidos_cliente[] = $pedido;
    }
    
} catch (Exception $e) {

    // em caso de erro, registra o erro e impede a quebra da página
    error_log("erro ao carregar pedidos: " . $e->getMessage());
}

// fecha a porta de comunicação com o banco de dados
$mysql->fechar();

// função para traduzir o status no banco de dados (pendente, pago, etc) para texo legivel
function traduzir_status($status) {
    switch ($status) {
        case 'pendente':
            return 'Pendente de Pagamento';
        case 'pago':
            return 'Pagamento Confirmado';
        case 'enviado':
            return 'Pedido Enviado';
        case 'concluido':
            return 'Concluído';
        default:
            return ucfirst($status);
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus pedidos | UEtec</title>
    <link rel="stylesheet" href="../css/meusPedidos.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="../imagens/logo.png">
</head>

<body>
    <header>
        <nav>
            <a class="logo" href="../index.html">UEtec</a>
            <div class="menu-responsivo">
                <div class="linha1"></div>
                <div class="linha2"></div>
                <div class="linha3"></div>
            </div>
            <ul class="menu-topo">
                <li><a href="../index.html #link3">Fale conosco</a></li>
                <li><a href="paginaVendas.php" class="entrar">Voltar</a></li>
            </ul>
        </nav>
    </header>
    <section class="container1">
        <div class="bloco1Container1">
            <p class="tituloContainer1">Meus Pedidos</p>

            <div class="corItems">
            
    <?php if (empty($pedidos_cliente)): ?>
        <p style="text-align: center; padding: 30px; font-size: 1.1rem; color: #515357;">Você ainda não fez nenhum pedido.</p>
    <?php else: ?>
        
        <?php foreach ($pedidos_cliente as $pedido): ?>
            <div class="masterCard">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
                    <p style="font-size: 1.2rem; font-weight: 600;">Código de Pedido: <?php echo htmlspecialchars($pedido['codigo_pedido'] ?? 'N/A'); ?></p>
                    <p style="font-size: 0.9rem; color: #777; text-align: right;">Em: <?php echo htmlspecialchars($pedido['data_pedido']); ?></p>
                </div>
                
                <p style="font-size: 1rem; margin-bottom: 10px; color: #AB0D0D; font-weight: 500;">
                    Status: <?php echo traduzir_status(htmlspecialchars($pedido['status'])); ?>
                </p>

                <ul style="list-style-type: none; padding: 0;">
                    <?php foreach ($pedido['itens'] as $item): ?>
                        <li style="margin-top: 5px; font-size: 1rem;">
                            <?php echo htmlspecialchars($item['quantidade']); ?>x - 
                            <?php echo htmlspecialchars($item['nome_produto']); ?> 
                            (R$ <?php echo number_format(htmlspecialchars($item['preco_unitario']), 2, ',', '.'); ?>)
                        </li>
                    <?php endforeach; ?>
                </ul>
                
                <p style="font-size: 1.4rem; font-weight: 600; text-align: right; margin-top: 15px; color: #AB0D0D;">
                    Total: R$ <?php echo number_format(htmlspecialchars($pedido['total']), 2, ',', '.'); ?>
                </p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
        </div>

    </div>

    </section>
    <footer class="footer">
            <div class="bloco1Footer">
                © 2025 3° Informática para a Internet
            </div>

            <div class="bloco2Footer">
                        <a href="../politicaPrivacidade.html" class="politicaFooter">Política de privacidade</a>
                        <span class="politicaFooter">-</span>
                        <a href="../politicaReembolso.html" class="politicaFooter">Política de reembolso</a>
            </div>
        </footer>

    <script src="../js/index.js"></script>
    
</body>
</html>