<?php
// DICA 01: CONEXÃO COM O BANCO DE DADOS

 // instancia a classe pdo para realizar a conexão com o banco de dados
$pdo = new PDO('mysql:host=localhost;dbname=uetecbd', 'usuario', 'senha');

// DICA 02: CONSULTA SQL E PREPARAÇÃO

// define a instrução sql para selecionar o nome, preco e url da imagem de todos os produtos
$sql = "SELECT nome, preco, imagem_url FROM produtos";
// executa a consulta
$stmt = $pdo->query($sql);

// DICA 03: RECUPERAÇÃO DOS DADOS

// recupera todos os resultados da consulta em um array associativo (coluna => valor)
$produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h1>Produtos</h1>
<ul>
<?php 

// DICA 04: ITERAÇÃO E EXIBIÇÃO DE PRODUTOS

// inicia a iteração sobre o array de produtos obtido do banco de dados
foreach ($produtos as $produto): 
?>
    <li>
        <h2><?= htmlspecialchars($produto['nome']) ?></h2>
        <p>Preço: R$ <?= number_format($produto['preco'], 2, ',', '.') ?></p>

        <?php 

        // DICA 05: VALIDAÇÃO E EXIBIÇÃO DA IMAGEM

        // verifica se o campo imagem_url não está vazio e se o arquivo existe no sistema de arquivos
        if (!empty($produto['imagem_url']) && file_exists($produto['imagem_url'])): 
        ?>
            <img src="<?= htmlspecialchars($produto['imagem_url']) ?>" style="max-width: 200px;">
        <?php else: ?>
            <p>Sem imagem</p>
        <?php endif; ?>
    </li>
<?php endforeach; ?>
</ul>