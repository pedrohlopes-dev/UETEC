<?php
// inicia a sessão
session_start();

// verifica se o usuário esta logado
if (isset($_SESSION['log']) && $_SESSION['log'] === "ativo") {

    // remove todas as variáveis de sessão ativas
    session_unset(); 

    // encerra a sessão
    session_destroy();    

    // envia o cabeçalho http para redirecionar o navegador para a página de login
    header("Location: ../paginaLogin.html"); 
    exit; 
}

else {
    // se não estiver logado, avisa para o usuário
    echo "<script> alert('Você não entrou com sua conta faça o login primeiro'); window.location.href='../paginaLogin.html'; </script>";
}
?>