<?php
session_start(); // inicia sessão php

// SEGURANÇA: Verificar se está logado
if (!isset($_SESSION['log']) || $_SESSION['log'] !== 'ativo') {
    http_response_code(401); // retorna código http 401
    echo json_encode(['erro' => 'Não autorizado']);
    exit; // para execução
}

// Incluir a classe de conexão
require_once 'conexao.php'; // importa arquivo com classe de conexão ao banco

// Retornar sempre JSON
header('Content-Type: application/json'); // resposta será json

// Criar conexão com banco
$bd = new BancodeDados(); 
$bd->conecta();

// Pegar a ação que foi solicitada (vem da URL)
$acao = isset($_GET['acao']) ? $_GET['acao'] : '';

// Decidir o que fazer baseado na ação
switch ($acao) {
    case 'listar_produtos':
        listarProdutos($bd); // busca todos produtos do banco
        break;
    
    case 'adicionar_produto':
        adicionarProduto($bd); // insere novo produto
        break;
    
    case 'remover_produto':
        removerProduto($bd); // deleta produto
        break;
    
    case 'atualizar_estoque':
        atualizarEstoque($bd); //atualiza quantidade estoque
        break;

    case 'atualizar_nome':
        atualizarNome($bd); // atualiza nome
        break;

    case 'atualizar_descricao':
        atualizarDescricao($bd); // atualiza descricao
        break;

    case 'atualizar_preco':
        atualizarPreco($bd); // atualiza preço do produto
        break;

    case 'atualizar_imagem':
        atualizarImagem($bd); // atualizar imagem do produto
        break;
    
    case 'listar_pedidos':
        listarPedidos($bd); // busca pedidos dos clientes
        break;
    
    case 'dashboard':
        getDashboard($bd); //retorna resumo de estatísticas
        break;
    
    case 'relatorio_vendas':
        getRelatorioVendas($bd); // retorna relatório de vendas
        break;
    
    default:
        http_response_code(400); // código 400 = requisição inválida
        echo json_encode(['erro' => 'Ação inválida']); 
}

// Fechar conexão com banco
$bd->fechar();

// ============================================
// FUNÇÕES
// ============================================

// LISTAR TODOS OS PRODUTOS
function listarProdutos($bd) {

    // query sql: busca produtos e faz join com categorias
    // left join = traz produto mesmo q não tenha categoria
    $query = "SELECT p.*, c.nome as categoria_nome 
              FROM produtos p 
              LEFT JOIN categorias c ON p.id_categoria = c.id_categoria 
              ORDER BY p.nome";
    
    $resultado = mysqli_query($bd->con, $query); // executa query
    $produtos = []; //array vazio que vai receber produtos

    // percorre cada linha do resultado
    while ($row = mysqli_fetch_assoc($resultado)) {
        $produtos[] = $row; // adiciona produto ao array
    }
    
    echo json_encode($produtos); // converte array php emm json e retorna
}


// ADICIONAR PRODUTO NOVO
function adicionarProduto($bd) {
    // Verificar se os dados de texto obrigatórios foram enviados
    if (!isset($_POST['nome']) || !isset($_POST['preco']) || !isset($_POST['estoque'])) {
        http_response_code(400);
        echo json_encode(['erro' => 'Dados de produto insuficientes (nome, preço ou estoque).']);
        return;
    }
    
    // 1. Receber e preparar dados de texto
    // mysqli_real_escape_string: previne SQL Injection (adiciona escape em caracteres especiais)
    $nome = mysqli_real_escape_string($bd->con, $_POST['nome']);
    $descricao = mysqli_real_escape_string($bd->con, $_POST['descricao'] ?? ''); // Recebe a descrição
    $preco = floatval($_POST['preco']);
    $estoque = intval($_POST['estoque']); // Recebe o estoque
    $id_categoria_raw = $_POST['id_categoria'] ?? 'NULL'; // Recebe o ID da categoria
    
    // Processa id_categoria para ser um inteiro ou a string 'NULL'
    // Se categoria for número válido, converte para int, senão usa NULL
    $id_categoria = (is_numeric($id_categoria_raw) && $id_categoria_raw > 0) 
        ? intval($id_categoria_raw) 
        : 'NULL';

    // Caminho padrão caso não haja upload
    $imagem_url = '../imagens/semfoto.png'; // Usando a imagem de placeholder existente
    
    // 2. Processar upload da imagem
    // verifica se foi enviado sem erro
    if (isset($_FILES['imagem_produto']) && $_FILES['imagem_produto']['error'] === UPLOAD_ERR_OK) {
        $arquivo = $_FILES['imagem_produto'];
        $nome_original = basename($arquivo['name']); // pega nome do arquivo
        
        // Diretório de upload (relativo ao api_admin.php que está em /php/)
        $diretorio_upload = '../imagens/produtos/'; // pasta destino
        
        // Cria um nome de arquivo único para evitar colisões
        $extensao = pathinfo($nome_original, PATHINFO_EXTENSION); // extrai extensão
        $nome_unico = uniqid() . '.' . $extensao; // uniqid gera o id único
        $caminho_completo = $diretorio_upload . $nome_unico;

        // Verifica e cria o diretório se não existir
        if (!is_dir($diretorio_upload)) {
            // Tenta criar o diretório recursivamente com permissão 0777
            @mkdir($diretorio_upload, 0777, true); // @ suprime avisos, 0777 = permissão total, true = recursivo
        }
        
        // Move o arquivo temporário para o destino final
        if (move_uploaded_file($arquivo['tmp_name'], $caminho_completo)) {
            $imagem_url = $caminho_completo; // atualiza caminhoda imagem
        } else {
            error_log("Falha ao mover arquivo."); // registra erro no log
        }
    }

    // 3. Inserir no banco de dados com TODOS os campos
    $query = "INSERT INTO produtos (nome, descricao, preco, estoque, imagem_url, id_categoria) 
              VALUES ('$nome', '$descricao', $preco, $estoque, '$imagem_url', $id_categoria)";
    
    if (mysqli_query($bd->con, $query)) {
        echo json_encode([
            'sucesso' => true, 
            'mensagem' => 'Produto adicionado com sucesso',
            'id' => mysqli_insert_id($bd->con) // id produto recém inserido
        ]);
    } else {
        http_response_code(500); // erro de servidor 500
        echo json_encode(['erro' => 'Erro ao adicionar produto: ' . mysqli_error($bd->con)]);
    }
}

// REMOVER PRODUTO
function removerProduto($bd) {
    // file_get_contents('php://input'): lê corpo da requisição POST (JSON)
    $dados = json_decode(file_get_contents('php://input'), true); // converte json em array php
    $id = intval($dados['id']); // pega id e converte para inteiro
    
    // Primeiro deleta os itens de pedidos relacionados
        mysqli_query($bd->con, "DELETE FROM itens_pedido WHERE id_produto = $id");
// Depois deleta o produto
        $query = "DELETE FROM produtos WHERE id_produto = $id";
    
    if (mysqli_query($bd->con, $query)) {
        echo json_encode(['sucesso' => true, 'mensagem' => 'Produto removido com sucesso']);
    } else {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro ao remover produto: ' . mysqli_error($bd->con)]);
    }
}

// ATUALIZAR ESTOQUE
function atualizarEstoque($bd) {
    $dados = json_decode(file_get_contents('php://input'), true);
    $id = intval($dados['id']);
    $quantidade = intval($dados['quantidade']);
    
    $query = "UPDATE produtos SET estoque = $quantidade WHERE id_produto = $id";
    
    if (mysqli_query($bd->con, $query)) {
        echo json_encode(['sucesso' => true, 'mensagem' => 'Estoque atualizado com sucesso']);
    } else {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro ao atualizar estoque: ' . mysqli_error($bd->con)]);
    }
}

function atualizarNome($bd) {
    // Recebe dados JSON
    $dados = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($dados['id']) || !isset($dados['nome'])) {
        http_response_code(400);
        echo json_encode(['erro' => 'Dados insuficientes (id ou nome)']);
        return;
    }
    
    $id = intval($dados['id']); // ID é número
    $nome = mysqli_real_escape_string($bd->con, $dados['nome']); // Nome é TEXTO (proteção SQL Injection)
    
    // Validação básica
    if (empty($nome)) {
        http_response_code(400);
        echo json_encode(['erro' => 'O nome não pode estar vazio']);
        return;
    }
    
    // SQL correto com aspas ao redor do nome
    $query = "UPDATE produtos SET nome = '$nome' WHERE id_produto = $id";
    
    if (mysqli_query($bd->con, $query)) {
        // Verifica se alguma linha foi afetada
        if (mysqli_affected_rows($bd->con) > 0) {
            echo json_encode(['sucesso' => true, 'mensagem' => 'Nome atualizado com sucesso']);
        } else {
            echo json_encode(['sucesso' => false, 'erro' => 'Produto não encontrado ou nome já é o mesmo']);
        }
    } else {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro ao atualizar nome: ' . mysqli_error($bd->con)]);
    }
}

function atualizarDescricao($bd) {
    // Recebe dados JSON
    $dados = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($dados['id']) || !isset($dados['descricao'])) {
        http_response_code(400);
        echo json_encode(['erro' => 'Dados insuficientes (id ou nome)']);
        return;
    }
    
    $id = intval($dados['id']); // ID é número
    $descricao = mysqli_real_escape_string($bd->con, $dados['descricao']); // Nome é TEXTO (proteção SQL Injection)
    
    // Validação básica
    if (empty($descricao)) {
        http_response_code(400);
        echo json_encode(['erro' => 'A descricao não pode estar vazio']);
        return;
    }
    
    // SQL correto com aspas ao redor do nome
    $query = "UPDATE produtos SET descricao = '$descricao' WHERE id_produto = $id";
    
    if (mysqli_query($bd->con, $query)) {
        // Verifica se alguma linha foi afetada
        if (mysqli_affected_rows($bd->con) > 0) {
            echo json_encode(['sucesso' => true, 'mensagem' => 'Descricao atualizado com sucesso']);
        } else {
            echo json_encode(['sucesso' => false, 'erro' => 'Produto não encontrado ou descricao já é a mesma']);
        }
    } else {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro ao atualizar nome: ' . mysqli_error($bd->con)]);
    }
}

function atualizarPreco($bd) {
    $dados = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($dados['id']) || !isset($dados['preco'])) {
        http_response_code(400);
        echo json_encode(['erro' => 'Dados insuficientes (id ou preco)']);
        return;
    }
    
    $id = intval($dados['id']);
    $preco = floatval($dados['preco']); 
    
    if ($preco <= 0) { 
        http_response_code(400);
        echo json_encode(['erro' => 'O preço deve ser maior que zero']);
        return;
    }
    
    $query = "UPDATE produtos SET preco = $preco WHERE id_produto = $id";
    
    if (mysqli_query($bd->con, $query)) {
        if (mysqli_affected_rows($bd->con) > 0) {
            echo json_encode(['sucesso' => true, 'mensagem' => 'Preço atualizado com sucesso']);
        } else {
            echo json_encode(['sucesso' => false, 'erro' => 'Produto não encontrado ou preço já é o mesmo']);
        }
    } else {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro ao atualizar preço: ' . mysqli_error($bd->con)]);
    }
}

function atualizarImagem($bd) {
    // Verifica se o ID foi enviado
    if (!isset($_POST['id'])) {
        http_response_code(400);
        echo json_encode(['erro' => 'ID do produto não informado']);
        return;
    }
    
    $id = intval($_POST['id']);
    
    // Verifica se a imagem foi enviada
    if (!isset($_FILES['imagem']) || $_FILES['imagem']['error'] !== UPLOAD_ERR_OK) {
        http_response_code(400);
        echo json_encode(['erro' => 'Nenhuma imagem foi enviada']);
        return;
    }
    
    $arquivo = $_FILES['imagem'];
    $nome_original = basename($arquivo['name']);
    $diretorio_upload = '../imagens/produtos/';
    
    // Cria nome único
    $extensao = pathinfo($nome_original, PATHINFO_EXTENSION);
    $nome_unico = uniqid() . '.' . $extensao;
    $caminho_completo = $diretorio_upload . $nome_unico;
    
    // Cria diretório se não existir
    if (!is_dir($diretorio_upload)) {
        @mkdir($diretorio_upload, 0777, true);
    }
    
    // Move o arquivo
    if (move_uploaded_file($arquivo['tmp_name'], $caminho_completo)) {
        // Atualiza no banco
        $query = "UPDATE produtos SET imagem_url = '$caminho_completo' WHERE id_produto = $id";
        
        if (mysqli_query($bd->con, $query)) {
            if (mysqli_affected_rows($bd->con) > 0) {
                echo json_encode(['sucesso' => true, 'mensagem' => 'Imagem atualizada com sucesso']);
            } else {
                echo json_encode(['sucesso' => false, 'erro' => 'Produto não encontrado']);
            }
        } else {
            http_response_code(500);
            echo json_encode(['erro' => 'Erro ao atualizar imagem: ' . mysqli_error($bd->con)]);
        }
    } else {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro ao fazer upload da imagem']);
    }
}

// LISTAR PEDIDOS
function listarPedidos($bd) {
    // inner join: traz apenas pedidos que tem cliente associado
    $query = "SELECT p.*, c.nome, c.sobrenome, c.email 
              FROM pedidos p 
              INNER JOIN clientes c ON p.id_cliente = c.id_cliente 
              ORDER BY p.data_pedido DESC 
              LIMIT 50"; // limita a 50 pedidos mais recentes
    
    $resultado = mysqli_query($bd->con, $query);
    $pedidos = [];
    
    while ($row = mysqli_fetch_assoc($resultado)) {
        $pedidos[] = $row;
    }
    
    echo json_encode($pedidos);
}

// DASHBOARD - RESUMO
function getDashboard($bd) {
    // Pedidos de hoje
    // curdate() = data atual 
    $query_pedidos = "SELECT COUNT(*) as total FROM pedidos WHERE DATE(data_pedido) = CURDATE()";
    $result = mysqli_query($bd->con, $query_pedidos);
    $pedidos_hoje = mysqli_fetch_assoc($result)['total'];
    
    // Faturamento de hoje
    // coalesce: retorna 0 se sum for null (caso não tenha vendas)
    $query_faturamento = "SELECT COALESCE(SUM(total), 0) as faturamento 
                          FROM pedidos 
                          WHERE DATE(data_pedido) = CURDATE() AND status = 'pago'";
    $result = mysqli_query($bd->con, $query_faturamento);
    $faturamento = mysqli_fetch_assoc($result)['faturamento'];
    
    // Total de produtos
    $query_produtos = "SELECT COUNT(*) as total FROM produtos";
    $result = mysqli_query($bd->con, $query_produtos);
    $total_produtos = mysqli_fetch_assoc($result)['total'];
    
    // Produtos com estoque baixo (menos de 10)
    $query_estoque_baixo = "SELECT COUNT(*) as total FROM produtos WHERE estoque < 10";
    $result = mysqli_query($bd->con, $query_estoque_baixo);
    $estoque_baixo = mysqli_fetch_assoc($result)['total'];
    
    // retorna tudo em json formatado
    echo json_encode([
        'pedidos_hoje' => $pedidos_hoje,
        'faturamento_hoje' => number_format($faturamento, 2, ',', '.'), // formata: 12.23 -> 232,32
        'total_produtos' => $total_produtos,
        'estoque_baixo' => $estoque_baixo
    ]);
}

// RELATÓRIO DE VENDAS
function getRelatorioVendas($bd) {
    // Total vendido nos últimos 30 dias
    // DATE_SUB: subtrai 30 dias da data atual
    $query_total = "SELECT COALESCE(SUM(total), 0) as total_vendas 
                    FROM pedidos 
                    WHERE data_pedido >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) 
                    AND status = 'pago'";
    $result = mysqli_query($bd->con, $query_total);
    $total_vendas = mysqli_fetch_assoc($result)['total_vendas'];
    
    // Produto MAIS vendido
    // agrupa por produto e ordena pela quantidade vendida (DESC = decrecente)
    $query_mais_vendido = "SELECT p.nome, SUM(ip.quantidade) as total_vendido 
                           FROM itens_pedido ip 
                           INNER JOIN produtos p ON ip.id_produto = p.id_produto 
                           INNER JOIN pedidos ped ON ip.id_pedido = ped.id_pedido 
                           WHERE ped.data_pedido >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) 
                           GROUP BY p.id_produto 
                           ORDER BY total_vendido DESC 
                           LIMIT 1"; // pega só o 1º mais vendido
    $result = mysqli_query($bd->con, $query_mais_vendido);
    $mais_vendido = mysqli_fetch_assoc($result);
    
    // Produto MENOS vendido
    // LEFT JOIN: inclui produtos que nunca foram vendidos (quantidade = 0)
    $query_menos_vendido = "SELECT p.nome, COALESCE(SUM(ip.quantidade), 0) as total_vendido 
                            FROM produtos p 
                            LEFT JOIN itens_pedido ip ON p.id_produto = ip.id_produto 
                            LEFT JOIN pedidos ped ON ip.id_pedido = ped.id_pedido 
                            AND ped.data_pedido >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) 
                            GROUP BY p.id_produto 
                            ORDER BY total_vendido ASC 
                            LIMIT 1"; // pega o 1º menos vendido
    $result = mysqli_query($bd->con, $query_menos_vendido);
    $menos_vendido = mysqli_fetch_assoc($result);
    
    echo json_encode([
        'total_vendas' => number_format($total_vendas, 2, ',', '.'),
        'mais_vendido' => $mais_vendido['nome'] ?? 'N/A',// ?? 'N/A' = se não existir, usa 'N/A'
        'menos_vendido' => $menos_vendido['nome'] ?? 'N/A'
    ]);
}
?>