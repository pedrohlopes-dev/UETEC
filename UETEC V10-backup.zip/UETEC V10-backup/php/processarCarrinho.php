<?php
// inicia a sessão
session_start();

// verifica se a requisição é do tipo POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // pega o JSON do corpo da requisição
    $dados_json = file_get_contents('php://input');
    
    // decodifica o JSON para um array PHP
    $carrinho = json_decode($dados_json, true);

    // verifica se os dados são válidos
    if ($carrinho) {
        // armazena o array do carrinho na variável de sessão
        $_SESSION['carrinho_pedido'] = $carrinho;
        
        // envia uma resposta de sucesso
        echo json_encode(['success' => true]);
    } else {
        // envia uma resposta de erro
        echo json_encode(['success' => false, 'message' => 'Dados inválidos.']);
    }
} else {
    // responde com erro se não for um POST
    http_response_code(405); // metodo não permitido
    echo json_encode(['success' => false, 'message' => 'Método não permitido.']);
}
?>