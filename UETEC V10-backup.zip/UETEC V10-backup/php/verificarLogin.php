<?php
// DICA 01:INICIAR E VALIDAR SESSÃO

// inicia a sessão e a conexão com o banco de dados
session_start();
require_once('conexao.php');

$mysql = new BancodeDados();
$mysql->conecta();

// DICA 02: PROCESSAMENTO MÉTODO POST

// verifica se os dados de login foram enviados
if (isset($_POST['email']) && isset($_POST['senha'])) {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

// DICA 03: PREVENÇÃO DE SQL INJECTION

    // busca as credenciais de forma segura usando prepared statements
    $stmt = $mysql->con->prepare(
        "SELECT senha_hash, tipo_usuario, id_cliente FROM usuarios WHERE email = ?"
    );
    
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

// DICA 04: VERIFICAR USUÁRIO

    // verifica se o e-mail existe no banco de dados
    if ($result->num_rows > 0) {
        $usuario = $result->fetch_assoc();
        $senha_hash_armazenada = $usuario['senha_hash'];
        $tipo_usuario = $usuario['tipo_usuario'];

// DICA 05: VERIFICAR SENHA

        // valida a senha com o hash armazenado
        if (password_verify($senha, $senha_hash_armazenada)) {
            
            // senha correta: define as variáveis de sessão para manter o usuário logado
            $_SESSION['log'] = 'ativo';
            $_SESSION['id_cliente'] = $usuario['id_cliente'];
            
            // DICA 06: REDIRECIONAR USUARIO

            // direciona o usuário de acordo com o nível (admin ou cliente)
            if ($tipo_usuario == 'admin') {
                echo "<script> window.location.href='../php/paginaAdm.php';</script>";
            } else {
                echo "<script> window.location.href='../php/paginaVendas.php';</script>";
            }
        } else {
            // aviso de senha incorreta
            echo "<script>alert('Senha incorreta! Tente novamente.'); window.location.href='../paginaLogin.html';</script>";
        }
    } else {
        // aviso de usuário não encontrado
        echo "<script>alert('Usuário não encontrado! Tente novamente.'); window.location.href='../paginaLogin.html';</script>";
    }
} else {

    // DICA 07: ACESSO DIRETO (SEM DADOS POST)

    // redireciona o usuário de volta para a página de login se não houver dados
    echo "<script>window.location.href='../paginaLogin.html';</script>";
}

// fecha a conexão com o banco de dados
$mysql->con->close();
?>