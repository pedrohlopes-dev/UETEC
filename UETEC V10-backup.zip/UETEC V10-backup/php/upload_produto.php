<?php
// DICA 01: VERIFICAÇÃO DO MÉTODO E INICIALIZAÇÃO DE VARIÁVEIS

// verifica se a requisição é do tipo post
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
// realiza a atribuição das variáveis nome e preço do produto, aplicando o operador null coalesce (??) para definir valores padrão caso as chaves não existam no array post
    $nome = $_POST['nomeProduto'] ?? '';
    $preco = $_POST['precoProduto'] ?? 0;

    // DICA 02: VALIDAÇÃO DO ARQUIVO DE IMAGEM

    // verifica a submissão e o status de erro do arquivo de imagem
    if (isset($_FILES['imagemProduto']) && $_FILES['imagemProduto']['error'] === UPLOAD_ERR_OK) {
        // cria um nome de arquivo único com timestamp para evitar conflito
        $nomeArquivo = time() . '_' . basename($_FILES['imagemProduto']['name']);
        // define o diretório de destino para a imagem
        $diretorioUpload = 'uploads/';

        // cria o diretório de uploads se ele não existir
        if (!is_dir($diretorioUpload)) {
            mkdir($diretorioUpload, 0755, true);
        }

        // define o caminho de destino do arquivo no servidor
        $caminhoCompleto = $diretorioUpload . $nomeArquivo;

        // DICA 03: MOVIMENTAÇÃO DO ARQUIVO E PERSISTÊNCIA DE DADOS

        // move o arquivo da área temporária para o diretório de destino
        if (move_uploaded_file($_FILES['imagemProduto']['tmp_name'], $caminhoCompleto)) {
            // instancia a classe pdo para realizar a conexão com o banco de dados
            $pdo = new PDO('mysql:host=localhost;dbname=uetecbd', 'usuario', 'senha');
            
            // prepara a query sql para inserir os dados do produto
            $sql = "INSERT INTO produtos (nome, preco, imagem_url) VALUES (:nome, :preco, :imagem)";
            $stmt = $pdo->prepare($sql);
            
            // executa a query preparada para salvar os dados no banco
            $stmt->execute([
                ':nome' => $nome,
                ':preco' => $preco,
                ':imagem' => $caminhoCompleto
            ]);
            
            // aviso de cadastro com sucesso
            echo "Produto cadastrado com sucesso!";
        } else {
            // aviso de erro ao mover o arquivo
            echo "Erro ao mover a imagem.";
        }
    } else {
        // aviso de erro na imagem
        echo "Imagem não enviada ou erro no upload.";
    }
}
?>