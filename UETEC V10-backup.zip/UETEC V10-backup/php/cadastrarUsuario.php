<?php
// DICA 01: INCLUSÃO DE CONEXÃO E PREPARAÇÃO

// carrega o arquivo de conexão com o banco de dados
require_once('conexao.php');

// inicia a conexão com o banco de dados
$mysql = new BancodeDados();
$mysql->conecta();

// DICA 02: COLETA DE DADOS

// coleta os dados enviados pelo formulário
$nome       = $_POST['nome'];
$sobrenome  = $_POST['sobrenome'];
$pemail      = $_POST['email'];

// DICA 03: VALIDAR E-MAIL

// verifica se o e-mail termina com @etec.sp.gov.br
if (!preg_match("/^[a-zA-Z0-9._%+-]+@etec\.sp\.gov\.br$/", $pemail)) {
    // se o e-mail não for válido, mostra mensagem de erro e redireciona para a pagina de login
    echo "<script>alert('e-mail inválido use apenas e-mails @etec.sp.gov.br'); window.location.href='../paginaLogin.html';</script>";
    exit;
}

$telefone   = $_POST['telefone'];
$senha      = $_POST['senha'];
// transforma o código da etec em um número inteiro
$cod_etec   = intval($_POST['cod_etec']);
$genero     = $_POST['genero'];

// DICA 04: VERIFICAR CÓDIGO ETEC

// prepara uma busca para checar se o código da etec existe
$check = $mysql->con->prepare("SELECT cod_etec FROM etecs WHERE cod_etec = ?");
// associa o código
$check->bind_param("i", $cod_etec);
// executa a busca
$check->execute();
$result = $check->get_result();

// se a busca não encontrou, o código da etec é inválido
if ($result->num_rows === 0) {
    // mostra mensagem de erro e redireciona para a pagina de cadastro
    echo "<script>alert('código da etec inválido'); window.location.href='../paginaCadastro.html';</script>";
    exit;
}

// DICA 05: CRIPTOGRAFIA DE SENHA

// usa a função segura do php para criptografar a senha do usuário
$senha_hash = password_hash($senha, PASSWORD_DEFAULT);

// DICA 06: INSERÇÃO NA TABELA CLIENTES

// prepara o comando para salvar os dados pessoais do cliente
$stmt1 = $mysql->con->prepare("INSERT INTO clientes (nome, sobrenome, email, telefone, genero) VALUES (?, ?, ?, ?, ?)");
// associa os valores
$stmt1->bind_param("sssss", $nome, $sobrenome, $pemail, $telefone, $genero);
// executa a inserção
$stmt1->execute();
// pega o id do cliente que será usado na próxima inserção
$id_cliente = $mysql->con->insert_id;

// DICA 07: INSERÇÃO NA TABELA USUÁRIOS

// prepara o comando para criar a conta de login e a senha criptografada
$stmt2 = $mysql->con->prepare("INSERT INTO usuarios (email, senha_hash, cod_etec, tipo_usuario, id_cliente) VALUES (?, ?, ?, 'cliente', ?)");
// associa os valores
$stmt2->bind_param("ssii", $pemail, $senha_hash, $cod_etec, $id_cliente);
// executa a inserção da conta de login
$stmt2->execute();

// DICA 08: FINALIZAR

// fecha a conexão com o banco de dados
$mysql->fechar();

// mostra mensagem de sucesso e redireciona para a página de login
echo "<script>alert('cadastro realizado com sucesso'); window.location.href='../paginaLogin.html';</script>";
?>