<?php
// inicia a definição da classe para gerenciar a conexão com o banco de dados
class BancodeDados {

    // define informações para o acesso ao banco
    private $host = "localhost";
    private $user = "root";
    private $senha = "";
    private $banco = "uetecbd";
    // define a propriedade pública que irá armazenar o link de conexão
    public $con;

    // define o método responsável por tentar estabelecer a conexão com o banco
    public function conecta() {
        // tenta conectar usando as informações definidas
        $this->con = mysqli_connect($this->host, $this->user, $this->senha, $this->banco);

        if (!$this->con) {
            // em caso de erro, para o script e mostra mensagem
            die("Problemas com a conexão: " . mysqli_connect_error());
        }
    }

    // define o método para encerrar a conexão ativa com o banco de dados
    public function fechar() {
        // verifica se a conexão existe antes de tentar fechar
        if ($this->con) {
            // fecha a conexão
            mysqli_close($this->con);
        }
    }
}
?>